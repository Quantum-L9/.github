#!/usr/bin/env python3
"""Qualify the pinned authority-resolution producer/driver, without modifying either.

Run with the QA venv Python, -B, with TMPDIR under OUTPUT. Existing run roots are never
removed or overwritten. The profiler only observes driver calls/returns and snapshots
scratch files before the driver's own TemporaryDirectory cleanup. It neither replaces
nor intercepts any driver/compiler function or alters a producer result.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import traceback
from dataclasses import asdict
from pathlib import Path

import yaml

BASE = Path('/home/ubuntu/l9-projection-campaign/authority-schema-run/positive')
AUTH = Path('/home/ubuntu/l9-projection-campaign/code-pr')
QA = Path('/tmp/l9-projection-qa.nBKv8FWo')
COMPILER_SRC = QA / 'compiler'
CONSUMER = QA / 'consumer'
EXE = QA / 'venv/bin/l9-semantic-compiler'
DRIVER = CONSUMER / 'tools/authority/produce_projection_bundle.py'
INSTALLED = QA / 'venv/lib/python3.12/site-packages/l9_semantic_compiler'
AUTH_REV = '290bcd90378577392640cea9c6053c178423f0da'
COMP_REV = '943db9a462d35ba66771a700ece77c746295f591'
CONS_REV = '8e4b352a0849ad6b04cda61ea9aa41f6fb1523a2'
PROFILE = 'l9.projection/authority-resolution@1'
COMPOSITION = 'l9.compose/authority-resolution@1'
REPO = 'Quantum-L9/.github'
CLASSES = ['invariants', 'contracts', 'authority_model', 'artifact_model']
EXPECTED_REFS = ['l9.source/invariants@1', 'l9.source/contracts@1',
                 'l9.source/authority-model@1', 'l9.source/artifact-model@1']
RUNS = ['run1', 'run2']

# These conditions guard the evidence directory, even when the harness is reused.
if Path(os.environ.get('TMPDIR', '/nonexistent')).resolve() != (BASE / 'tmp').resolve():
    raise RuntimeError('TMPDIR must be the isolated positive/tmp directory')
if not sys.dont_write_bytecode:
    raise RuntimeError('Python must be invoked with -B')
if any((BASE / n).exists() for n in RUNS):
    raise RuntimeError('refusing to overwrite existing run roots')

LOG = BASE / 'qualification.log'
SUMMARY = BASE / 'summary.json'
if LOG.exists() or SUMMARY.exists():
    raise RuntimeError('refusing to overwrite prior evidence')
log_file = LOG.open('x', encoding='utf-8')
summary = {'status': 'BLOCKED', 'scope': 'producer/driver positive qualification only',
           'not_proven': ['independent consumer replay', 'release admission', 'trusted replay',
                          'string_list minima'],
           'roots': {'authority': str(AUTH), 'compiler_checkout': str(COMPILER_SRC),
                     'consumer_checkout': str(CONSUMER), 'compiler_executable': str(EXE),
                     'installed_package': str(INSTALLED), 'output': str(BASE)},
           'commits_expected': {'authority': AUTH_REV, 'compiler': COMP_REV, 'consumer': CONS_REV},
           'preflight': {}, 'runs': {}, 'comparison': {}, 'errors': []}

def log(message):
    print(message, flush=True)
    print(message, file=log_file, flush=True)

def sha_bytes(b):
    return 'sha256:' + hashlib.sha256(b).hexdigest()

def sem_digest(value):
    return sha_bytes(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())

def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], check=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE).stdout

def document(path):
    return yaml.safe_load(git(AUTH, 'show', AUTH_REV + ':' + path))

def check(checks, name, condition, *, expected=None, observed=None):
    entry = {'passed': bool(condition)}
    if expected is not None: entry['expected'] = expected
    if observed is not None: entry['observed'] = observed
    checks[name] = entry
    log(f"{'PASS' if condition else 'FAIL'} {name}" + (f' observed={observed!r} expected={expected!r}' if not condition else ''))
    return bool(condition)

def write_summary():
    SUMMARY.write_text(json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=False) + '\n')

def tree(root):
    return {str(p.relative_to(root)): p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file()}

def coordinate(path, ref):
    return {'ref': ref, 'path': path, 'digest': sem_digest(document(path))}

def expected_governing(operation):
    result = {'repository': REPO, 'revision': AUTH_REV,
      'compiler_contract': coordinate('semantics/compiler_contract.yaml', 'l9.compiler/generic@1'),
      'compiler_manifest': coordinate('semantics/generic_compiler_manifest.yaml', 'l9.generic-compiler/global@1'),
      'source_registry': coordinate('semantics/canonical_sources.yaml', 'l9.canonical-sources/global@1'),
      'receipt_schema': coordinate('semantics/compiler_receipt.schema.yaml', 'l9.schema/compiler-receipt@1')}
    if operation == 'projection':
        result.update(engine_contract=coordinate('semantics/projection_engine_contract.yaml','l9.compiler/projection-engine@1'),
          artifact_schema=coordinate('semantics/projection_artifact.schema.yaml','l9.schema/projection-artifact@1'),
          profile_catalog=coordinate('semantics/projection_profiles.yaml','l9.projection-profile-catalog/global@1'),
          selector_model=coordinate('semantics/selector_model.yaml','l9.selector-model/global@1'))
    else:
        result.update(engine_contract=coordinate('semantics/composition_engine_contract.yaml','l9.compiler/composition-engine@1'),
          artifact_schema=coordinate('semantics/composed_projection.schema.yaml','l9.schema/composed-projection@1'),
          profile_catalog=coordinate('semantics/composition_profiles.yaml','l9.composition-profiles/global@1'))
    return result

try:
    log('Starting qualification; Python profiling is observational only. No driver or engine monkeypatches.')
    os.environ['GIT_OPTIONAL_LOCKS'] = '0'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    checks = summary['preflight']
    for key, root, expected in [('authority', AUTH, AUTH_REV), ('compiler', COMPILER_SRC, COMP_REV), ('consumer', CONSUMER, CONS_REV)]:
        head = git(root, 'rev-parse', 'HEAD').decode().strip()
        status = git(root, 'status', '--porcelain=v1', '--untracked-files=all').decode()
        check(checks, key + '_head', head == expected, expected=expected, observed=head)
        check(checks, key + '_worktree_clean', status == '', expected='', observed=status)
    source_root = COMPILER_SRC / 'src/l9_semantic_compiler'
    def pkg_files(root):
        return {str(p.relative_to(root)): p.read_bytes() for p in root.rglob('*')
                if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith(('.pyc','.pyo'))}
    src, installed = pkg_files(source_root), pkg_files(INSTALLED)
    git_records = git(COMPILER_SRC, 'ls-tree', '-r', '--full-tree', COMP_REV, 'src/l9_semantic_compiler').decode().splitlines()
    committed = {}
    for item in git_records:
        meta, path = item.split('\t', 1)
        _, kind, blob = meta.split()
        if kind == 'blob': committed[path.removeprefix('src/l9_semantic_compiler/')] = blob
    git_mismatches = []
    for name in sorted(set(src) | set(committed)):
        raw = src.get(name)
        calculated = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() if raw is not None else None
        if calculated != committed.get(name): git_mismatches.append({'path': name, 'committed_git_blob': committed.get(name), 'working_git_blob': calculated})
    diff = [{'path': p, 'source_sha256': sha_bytes(src[p]) if p in src else None,
             'installed_sha256': sha_bytes(installed[p]) if p in installed else None}
            for p in sorted(set(src) | set(installed)) if src.get(p) != installed.get(p)]
    summary['installed_package_comparison'] = {'source_file_count': len(src), 'installed_file_count': len(installed),
       'excludes': ['__pycache__', '*.pyc', '*.pyo'], 'difference_count': len(diff), 'differences': diff,
       'source_commit_blob_mismatches': git_mismatches,
       'source_files_sha256': {p: sha_bytes(v) for p,v in sorted(src.items())},
       'launcher_sha256': sha_bytes(EXE.read_bytes()), 'driver_sha256': sha_bytes(DRIVER.read_bytes())}
    check(checks, 'source_package_matches_pinned_commit', not git_mismatches, observed=git_mismatches)
    check(checks, 'installed_package_exact_source_bytes', not diff and len(src) == len(installed), observed=diff)
    version = importlib.metadata.version('l9-semantic-compiler')
    import l9_semantic_compiler
    from l9_semantic_compiler.engine.receipts import emit_receipt, validate_receipt_document
    from l9_semantic_compiler.passes.validate import schema_violations
    loaded = Path(l9_semantic_compiler.__file__).resolve()
    summary['python'] = {'executable': sys.executable, 'package_import': str(loaded), 'version': version,
                         'launcher_shebang': EXE.read_text().splitlines()[0]}
    check(checks, 'installed_package_actually_imported', loaded == (INSTALLED/'__init__.py').resolve(), observed=str(loaded))
    check(checks, 'compiler_executable_shebang', EXE.read_text().splitlines()[0] == '#!' + str(QA/'venv/bin/python'), observed=EXE.read_text().splitlines()[0])
    check(checks, 'driver_exact_commit_bytes', git(CONSUMER, 'show', CONS_REV + ':tools/authority/produce_projection_bundle.py') == DRIVER.read_bytes())
    catalog = document('semantics/projection_profiles.yaml')
    profiles = [p for p in catalog['projection_profiles'] if p.get('id') == PROFILE]
    compositions = [p for p in document('semantics/composition_profiles.yaml')['profiles'] if p.get('id') == COMPOSITION]
    check(checks, 'profile_declarations_unique', len(profiles) == 1 and len(compositions) == 1)
    profile, comp_profile = profiles[0], compositions[0]
    source_registry = document('semantics/canonical_sources.yaml')['sources']
    by_file = {Path(x['path']).name: x for x in source_registry if x.get('path') and x.get('id')}
    classes = list(profile['sources'])
    sources = [by_file[catalog['source_classes'][cls]['canonical_artifact']] for cls in classes]
    refs = [x['id'] for x in sources]
    check(checks, 'exact_declared_source_classes_order', classes == CLASSES, expected=CLASSES, observed=classes)
    check(checks, 'exact_declared_source_refs_order', refs == EXPECTED_REFS, expected=EXPECTED_REFS, observed=refs)
    profile_pin = {'ref': PROFILE, 'digest': sem_digest(profile)}
    composition_pin = {'ref': COMPOSITION, 'digest': sem_digest(comp_profile)}
    summary['declared'] = {'source_classes': classes, 'source_refs': refs, 'projection_profile': profile_pin,
                           'composition_profile': composition_pin,
                           'sources': [{'ref': s['id'], 'path': s['path'], 'digest': sem_digest(document(s['path']))} for s in sources]}
    check(checks, 'composition_profile_target_and_strategy', comp_profile['composes'] == {'projection_profile': PROFILE}
          and comp_profile['merge_strategy'] == {'placement':'source_class_namespace','source_coverage':'exact',
                'duplicate_source':'conflict','semantic_identity_collision':'require_equivalence'})
    if not all(c['passed'] for c in checks.values()):
        raise RuntimeError('Preflight failed: refusing to run producer')
    spec = importlib.util.spec_from_file_location('pinned_consumer_driver', DRIVER)
    driver = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = driver
    spec.loader.exec_module(driver)
    receipt_schema = document('semantics/compiler_receipt.schema.yaml')
    projection_schema = document('semantics/authority_resolution_projection.schema.yaml')
    composition_schema = document('semantics/authority_resolution_composition.schema.yaml')
    driver_path = str(DRIVER)

    for run in RUNS:
        info = summary['runs'][run] = {'output': str(BASE / run), 'produce_returned': False, 'checks': {},
                                      'commands': [], 'assemble_entered': False, 'assemble_returned': False,
                                      'exception': None, 'snapshots': []}
        trace_dir = BASE/'trace'/run
        trace_dir.mkdir(parents=True)
        log(f'BEGIN {run}: calling original driver.produce() with {EXE}')
        def profiler(frame, event, arg):
            if frame.f_code.co_filename != driver_path:
                return
            name = frame.f_code.co_name
            if name == '_assemble' and event == 'call':
                info['assemble_entered'] = True
                log(f'{run}: entered unchanged driver._assemble')
            if name == '_assemble' and event == 'return' and arg is None:
                # A return event is also generated on exception; only explicit normal
                # completion of produce() proves assembly completed without raising.
                info['assemble_return_event_seen'] = True
            if name == '_run' and event == 'return':
                try:
                    cmd = frame.f_locals.get('command', [])
                    completed = frame.f_locals.get('completed')
                    i = len(info['commands']) + 1
                    record = {'argv': cmd, 'returncode': getattr(completed,'returncode',None)}
                    if completed is not None:
                        for stream in ('stdout', 'stderr'):
                            text = getattr(completed, stream)
                            file = trace_dir / f'{i:02d}.{stream}.txt'
                            file.write_text(text, encoding='utf-8')
                            record[stream] = str(file.relative_to(BASE))
                            record[stream+'_sha256'] = sha_bytes(file.read_bytes())
                    info['commands'].append(record)
                    log(f"{run}: subprocess {cmd!r} rc={record['returncode']}")
                    if cmd and cmd[0] == str(EXE) and len(cmd) > 2 and cmd[1] in ('project','compose'):
                        scratch = Path(cmd[-1]).parent
                        if scratch.is_dir():
                            dst = BASE / 'producer-snapshots' / run / cmd[1]
                            shutil.copytree(scratch, dst, dirs_exist_ok=True)
                            info['snapshots'].append(str(dst.relative_to(BASE)))
                except Exception as exc:
                    info.setdefault('observer_errors', []).append(f'{type(exc).__name__}: {exc}')
        try:
            sys.setprofile(profiler)
            driver.produce(compiler=[str(EXE)], authority_root=AUTH, revision=AUTH_REV,
                           compiler_revision=COMP_REV, profile_ref=PROFILE,
                           composition_ref=COMPOSITION, output=BASE/run)
            info['produce_returned'] = True
            info['assemble_returned'] = info['assemble_entered']
        except Exception as exc:
            info['exception'] = {'type': f'{type(exc).__module__}.{type(exc).__name__}',
                                 'message': str(exc), 'traceback': traceback.format_exc()}
            log(f"BLOCKED {run} {info['exception']['type']}: {exc}")
        finally:
            sys.setprofile(None)
        c = info['checks']
        compiler_commands = [x['argv'][1] for x in info['commands'] if x['argv'] and x['argv'][0] == str(EXE)]
        check(c, 'produce_returned_normally', info['produce_returned'])
        check(c, 'unchanged_assemble_completed', info['assemble_returned'])
        check(c, 'exact_direct_compiler_command_sequence', compiler_commands == ['projection-coordinates','project','compose'], expected=['projection-coordinates','project','compose'], observed=compiler_commands)
        check(c, 'observer_no_errors', not info.get('observer_errors'), observed=info.get('observer_errors', []))
        files = tree(BASE/run) if (BASE/run).exists() else {}
        info['file_inventory_sha256'] = {p: sha_bytes(b) for p,b in files.items()}
        expected_files = {'bundle.lock.json', 'composed.json', 'receipts/composed.receipt.json'} | {f'projections/{s}.projection.json' for s in CLASSES} | {f'receipts/{s}.receipt.json' for s in CLASSES}
        check(c, 'complete_exact_11_file_inventory', set(files) == expected_files, expected=sorted(expected_files), observed=sorted(files))
        if set(files) != expected_files or not info['produce_returned']:
            continue
        def load(p): return json.loads(files[p])
        lock = load('bundle.lock.json')
        composition = load('composed.json')
        projections = {cls: load(f'projections/{cls}.projection.json') for cls in CLASSES}
        info['semantic_digests'] = {'projection_profile': profile_pin['digest'], 'composition_profile': composition_pin['digest'],
            'projections': {cls:projections[cls]['projection_digest'] for cls in CLASSES},
            'composition': composition['composition_digest']}
        check(c, 'lock_identity_authority_producer', lock['schema'] == 'l9.projection-bundle/v1' and
          lock['authority'] == {'repository': REPO, 'revision': AUTH_REV} and
          lock['producer'] == {'compiler':'l9-semantic-compiler','version':version,'repository':'Quantum-L9/l9-semantic-compiler-engine','revision':COMP_REV,'revision_basis':'caller_asserted'} and
          lock['generated_by'] == 'tools/authority/produce_projection_bundle.py', observed={'authority':lock.get('authority'),'producer':lock.get('producer')})
        check(c, 'profile_refs_and_independent_digests', lock['projection_profile'] == profile_pin and lock['composition_profile'] == composition_pin and composition['composition_profile'] == composition_pin)
        check(c, 'lock_declared_class_and_ref_order', [(x['source_class'],x['source_ref']) for x in lock['components']] == list(zip(CLASSES,EXPECTED_REFS)))
        check(c, 'composition_declared_class_and_ref_order', [(x['source_class'],x['source_ref']) for x in composition['components']] == list(zip(CLASSES,EXPECTED_REFS)))
        check(c, 'composition_namespace_exact_payloads', composition['payload'] == {cls:projections[cls]['payload'] for cls in CLASSES})
        check(c, 'composition_envelope_digest_independent', composition['composition_digest'] == sem_digest({k:v for k,v in composition.items() if k != 'composition_digest'}))
        check(c, 'composition_payload_schema_genuine_interpreter', not schema_violations(composition['payload'], composition_schema), observed=schema_violations(composition['payload'], composition_schema))
        check(c, 'lock_composed_file_binding', lock['composed'] == {'path':'composed.json','sha256':sha_bytes(files['composed.json']),'composition_digest':composition['composition_digest'],'receipt':'receipts/composed.receipt.json'})
        expected_comp_components = []
        for cls, source, lock_component in zip(CLASSES, sources, lock['components']):
            p = projections[cls]
            source_ref, source_digest = source['id'], sem_digest(document(source['path']))
            pfile = f'projections/{cls}.projection.json'
            subject = f'{PROFILE}#{source_ref}'
            check(c, cls + '.projection_coordinates_and_generated_by',
              p['source_ref'] == source_ref and p['source_digest'] == source_digest and
              p['projection_profile_ref'] == PROFILE and p['projection_profile_digest'] == profile_pin['digest'] and
              p['generated_by'] == {'compiler':'l9-semantic-compiler','version':version})
            check(c, cls + '.projection_digest_independent', p['projection_digest'] == sem_digest({k:v for k,v in p.items() if k != 'projection_digest'}))
            check(c, cls + '.projection_payload_schema_genuine_interpreter', not schema_violations(p['payload'],projection_schema), observed=schema_violations(p['payload'],projection_schema))
            check(c, cls + '.lock_component_exact', lock_component == {'source_class':cls,'source_ref':source_ref,'source_digest':source_digest,
                 'projection_digest':p['projection_digest'],'path':pfile,'sha256':sha_bytes(files[pfile]),'receipt':f'receipts/{cls}.receipt.json'})
            expected_comp_components.append({'source_class':cls,'source_ref':source_ref,'source_digest':source_digest,'projection_ref':subject,'projection_digest':p['projection_digest']})
        check(c, 'composition_component_coordinates_exact', composition['components'] == expected_comp_components)

        for cls in CLASSES + ['composed']:
            r = load(f'receipts/{cls}.receipt.json')
            is_comp = cls == 'composed'
            p = composition if is_comp else projections[cls]
            source = None if is_comp else sources[CLASSES.index(cls)]
            subject = f'{COMPOSITION}#{PROFILE}' if is_comp else f'{PROFILE}#{source["id"]}'
            operation = 'composition' if is_comp else 'projection'
            digest_field = 'composition_digest' if is_comp else 'projection_digest'
            expected_inputs = ([{'ref':x['projection_ref'],'digest':x['projection_digest']} for x in expected_comp_components] if is_comp else
                [{'ref':source['id'],'digest':sem_digest(document(source['path'])),'path':source['path'],'revision':AUTH_REV}])
            expected_profile = composition_pin if is_comp else profile_pin
            violations = schema_violations(r, receipt_schema)
            check(c, cls + '.compiler_receipt_schema', not violations, observed=violations)
            check(c, cls + '.receipt_subject_inputs_profile_output', r['exact_subject_ref'] == subject and r['operation'] == operation and
                  r['inputs'] == expected_inputs and r['profile'] == expected_profile and r['output'] == {'ref':subject,'digest':p[digest_field]})
            expected_gov = expected_governing(operation)
            check(c, cls + '.governing_coordinates_exact', r['governing_coordinates'] == expected_gov,
                  expected=expected_gov if r['governing_coordinates'] != expected_gov else None,
                  observed=r['governing_coordinates'] if r['governing_coordinates'] != expected_gov else None)
            check(c, cls + '.producer_identity', r['producer_identity'] == {'compiler':'l9-semantic-compiler','version':version})
            criteria = r['verification_basis']['criteria']
            required = ['payload_schema', 'composition_equivalence'] if is_comp else ['payload_schema','selection_equivalence']
            check(c, cls + '.receipt_result_criteria_unresolved', r['result'] == 'pass' and r['verification_basis']['unresolved_criteria'] == [] and
                  r['verification_basis']['coverage'] == 'complete' and all(criteria.get(k,{}).get('status') == 'pass' for k in required),
                  observed={'result':r['result'],'criteria':{k:criteria.get(k) for k in required},'unresolved_criteria':r['verification_basis']['unresolved_criteria']})
            artifact_file = 'composed.json' if is_comp else f'projections/{cls}.projection.json'
            check(c, cls + '.receipt_delivered_bytes', criteria.get('delivered_bytes',{}).get('status') == 'pass' and criteria['delivered_bytes']['content_digest'] == sha_bytes(files[artifact_file]))
            try:
                validate_receipt_document(r, expected_subject_ref=subject)
                validation_error = None
            except Exception as exc:
                validation_error = f'{type(exc).__name__}: {exc}'
            check(c, cls + '.genuine_receipt_validator', validation_error is None, observed=validation_error)
            generated = asdict(emit_receipt(subject_ref=r['exact_subject_ref'], operation=r['operation'], inputs=r['inputs'],
                profile=r['profile'], output=r['output'], governing=r['governing_coordinates'], result=r['result'],
                verification=r['verification_basis'], compiler_version=r['producer_identity']['version'], diagnostics=r.get('diagnostics',[])))
            # asdict produces tuples for dataclass list fields; JSON conversion normalizes them.
            generated = json.loads(json.dumps(generated))
            check(c, cls + '.genuine_receipt_reconstruction_exact', generated == r)
            base = {k:v for k,v in r.items() if k != 'receipt_digest'}
            pending = dict(base); pending['receipt_identity'] = 'pending'
            identity = 'l9.receipt-instance/' + sem_digest(pending).split(':',1)[1]
            check(c, cls + '.receipt_identity_independent', r['receipt_identity'] == identity)
            check(c, cls + '.receipt_digest_independent', r['receipt_digest'] == sem_digest(base))
            info.setdefault('receipts', {})[cls] = {'identity':r['receipt_identity'], 'digest':r['receipt_digest'],
               'result':r['result'], 'diagnostics':r.get('diagnostics'), 'unresolved_criteria':r['verification_basis']['unresolved_criteria'],
               'selected_criteria':{k:criteria.get(k) for k in required}}
    a = tree(BASE/'run1') if (BASE/'run1').exists() else {}
    b = tree(BASE/'run2') if (BASE/'run2').exists() else {}
    comparison = summary['comparison']
    comparison['run1_inventory'] = sorted(a)
    comparison['run2_inventory'] = sorted(b)
    comparison['file_results'] = {p: {'run1_sha256':sha_bytes(a[p]) if p in a else None,
                                       'run2_sha256':sha_bytes(b[p]) if p in b else None,
                                       'exact_bytes_equal':p in a and p in b and a[p] == b[p]}
                                  for p in sorted(set(a)|set(b))}
    comparison['inventory_equal'] = bool(a) and set(a) == set(b)
    comparison['all_exact_bytes_equal'] = bool(a) and set(a) == set(b) and all(a[p] == b[p] for p in a)
    log('Comparison inventories equal: ' + str(comparison['inventory_equal']))
    log('Comparison all exact file bytes equal: ' + str(comparison['all_exact_bytes_equal']))
    passed = (all(c['passed'] for c in summary['preflight'].values()) and
              all(summary['runs'][r]['checks'] and all(c['passed'] for c in summary['runs'][r]['checks'].values()) for r in RUNS)
              and comparison['inventory_equal'] and comparison['all_exact_bytes_equal'])
    summary['status'] = 'PASS' if passed else 'BLOCKED'
except Exception as exc:
    summary['errors'].append({'type':f'{type(exc).__module__}.{type(exc).__name__}','message':str(exc),'traceback':traceback.format_exc()})
    log(f'BLOCKED harness {type(exc).__name__}: {exc}')
finally:
    sys.setprofile(None)
    write_summary()
    log('FINAL: ' + summary['status'])
    log_file.close()
sys.exit(0 if summary['status'] == 'PASS' else 1)
