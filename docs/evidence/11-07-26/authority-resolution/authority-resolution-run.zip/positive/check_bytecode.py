#!/usr/bin/env python3
"""Compare existing import caches with source without writing caches or changing imports."""
import hashlib
import importlib.util
import json
import marshal
import struct
import types
from pathlib import Path

BASE = Path('/home/ubuntu/l9-projection-campaign/authority-schema-run/positive')
ROOT = Path('/tmp/l9-projection-qa.nBKv8FWo/venv/lib/python3.12/site-packages/l9_semantic_compiler')
DRIVER = Path('/tmp/l9-projection-qa.nBKv8FWo/consumer/tools/authority/produce_projection_bundle.py')

def canonical_code(code):
    constants = tuple(canonical_code(c) if isinstance(c, types.CodeType) else c for c in code.co_consts)
    return code.replace(co_filename='<source>', co_consts=constants)

def inspect(source, cached):
    data = cached.read_bytes()
    flags = int.from_bytes(data[4:8], 'little')
    entry = {'source': str(source), 'cache': str(cached), 'flags': flags,
             'cache_sha256': 'sha256:' + hashlib.sha256(data).hexdigest()}
    entry['magic_matches'] = data[:4] == importlib.util.MAGIC_NUMBER
    if flags == 0:
        mtime, size = struct.unpack('<II', data[8:16])
        entry['header_matches_source'] = (mtime == (int(source.stat().st_mtime) & 0xffffffff) and size == (source.stat().st_size & 0xffffffff))
    elif flags & 1:
        entry['header_matches_source'] = data[8:16] == importlib.util.source_hash(source.read_bytes())
    else:
        entry['header_matches_source'] = False
    cached_code = marshal.loads(data[16:])
    actual_code = compile(source.read_bytes(), str(source), 'exec', dont_inherit=True, optimize=0)
    entry['compiled_code_equal'] = canonical_code(cached_code) == canonical_code(actual_code)
    entry['passed'] = entry['magic_matches'] and entry['header_matches_source'] and entry['compiled_code_equal']
    return entry

entries = []
for cache in sorted(ROOT.rglob('*.cpython-312.pyc')):
    source = Path(importlib.util.source_from_cache(str(cache)))
    entries.append(inspect(source, cache))
driver_cache = Path(importlib.util.cache_from_source(str(DRIVER)))
if driver_cache.exists():
    entries.append(inspect(DRIVER, driver_cache))
result = {'python_cache_mode': 'PYTHONDONTWRITEBYTECODE prevents writing caches, not reading existing caches',
          'compiler_cache_count': sum(str(ROOT) in e['source'] for e in entries),
          'driver_cache_exists': driver_cache.exists(), 'entries': entries,
          'all_existing_bytecode_matches_source': all(e['passed'] for e in entries)}
(BASE/'bytecode-check.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print('compiler cache count:', result['compiler_cache_count'])
print('driver cache exists:', result['driver_cache_exists'])
print('all existing bytecode matches source:', result['all_existing_bytecode_matches_source'])
print('mismatches:', [(e['cache'], e['header_matches_source'], e['compiled_code_equal']) for e in entries if not e['passed']])
raise SystemExit(0 if result['all_existing_bytecode_matches_source'] else 1)
