#!/usr/bin/env python3
"""Append post-production integrity findings to the existing qualification summary."""
import hashlib
import json
import os
import subprocess
from pathlib import Path
import yaml

BASE = Path('/home/ubuntu/l9-projection-campaign/authority-schema-run/positive')
AUTH = Path('/home/ubuntu/l9-projection-campaign/code-pr')
REV = '290bcd90378577392640cea9c6053c178423f0da'
QA = Path('/tmp/l9-projection-qa.nBKv8FWo')
roots = {'authority': (AUTH, REV), 'compiler': (QA/'compiler', '943db9a462d35ba66771a700ece77c746295f591'),
         'consumer': (QA/'consumer','8e4b352a0849ad6b04cda61ea9aa41f6fb1523a2')}
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
def git(root, *args):
    return subprocess.run(['git','-C',str(root),*args],check=True,stdout=subprocess.PIPE).stdout

def coord(path, ref):
    raw = git(AUTH,'show',REV+':'+path)
    return {'path':path,'ref':ref,'digest':'sha256:'+hashlib.sha256(raw).hexdigest()}

summary_path = BASE/'summary.json'
s = json.loads(summary_path.read_text())
bytecode = json.loads((BASE/'bytecode-check.json').read_text())
post = {'installed_bytecode_cache_matches_source': bytecode['all_existing_bytecode_matches_source'],
        'compiler_bytecode_caches_checked': bytecode['compiler_cache_count'],
        'consumer_driver_bytecode_cache_present': bytecode['driver_cache_exists'],
        'bytecode_check_evidence': 'bytecode-check.json', 'repositories': {}, 'runs': {}}
for key,(root,revision) in roots.items():
    head = git(root,'rev-parse','HEAD').decode().strip()
    status = git(root,'status','--porcelain=v1','--untracked-files=all').decode()
    post['repositories'][key] = {'head':head,'expected_revision':revision,'head_matches':head==revision,
                                  'worktree_clean':status=='','porcelain':status}
for run in ('run1','run2'):
    r = s['runs'][run]
    commands = []
    for command in r['commands']:
        if command['argv'][0] != s['roots']['compiler_executable']: continue
        out = yaml.safe_load((BASE/command['stdout']).read_text())
        commands.append({'subcommand':command['argv'][1], 'returncode':command['returncode'],
                         'result':out.get('result') if isinstance(out,dict) else None,
                         'stderr_empty':(BASE/command['stderr']).read_bytes()==b''})
    expected_projection_schema = coord('semantics/authority_resolution_projection.schema.yaml','l9.schema/authority-resolution-projection@1')
    expected_composition_schema = coord('semantics/authority_resolution_composition.schema.yaml','l9.schema/authority-resolution-composition@1')
    receipt_checks = {}
    for cls in ('invariants','contracts','authority_model','artifact_model','composed'):
        receipt = json.loads((BASE/run/'receipts'/f'{cls}.receipt.json').read_text())
        criterion = receipt['verification_basis']['criteria']['payload_schema']
        expected_schema = expected_composition_schema if cls == 'composed' else expected_projection_schema
        expected_id = 'l9.composed-projection.authority-resolution/v1' if cls == 'composed' else 'l9.projection.authority-resolution/v1'
        receipt_checks[cls] = {
            'all_reported_criteria_pass_or_not_applicable':all(x['status'] in ('pass','not_applicable') for x in receipt['verification_basis']['criteria'].values()),
            'payload_schema_coordinate_exact': criterion.get('schema_artifact') == expected_schema and criterion.get('schema') == expected_id,
            'diagnostics_empty':receipt['diagnostics']==[]}
    post['runs'][run] = {'compiler_commands':commands,
        'compiler_command_exit_codes_all_zero':len(commands)==3 and all(c['returncode']==0 for c in commands),
        'project_and_compose_return_pass':len(commands)==3 and [c['result'] for c in commands[1:]]==['pass','pass'],
        'stderr_all_empty':all(c['stderr_empty'] for c in commands), 'receipt_additional_checks':receipt_checks}
post['all_post_checks_pass'] = (post['installed_bytecode_cache_matches_source'] and
    all(r['head_matches'] and r['worktree_clean'] for r in post['repositories'].values()) and
    all(r['compiler_command_exit_codes_all_zero'] and r['project_and_compose_return_pass'] and r['stderr_all_empty'] and
        all(all(c.values()) for c in r['receipt_additional_checks'].values()) for r in post['runs'].values()))
s['post_production_integrity'] = post
s['execution_constraint_deviation'] = {'requested_writes_confined_to_output': False,
    'explanation': 'The terminal tool automatically saved three truncated output transcripts outside the requested directory. These platform-generated files were not written by the harness or producer and were not removed because the instruction forbids altering locations outside the output directory.',
    'platform_generated_transcripts': [
      '/home/ubuntu/terminal_full_output/2026-11-07_16-59-39_658676_412.txt',
      '/home/ubuntu/terminal_full_output/2026-11-07_17-00-29_665141_412.txt',
      '/home/ubuntu/terminal_full_output/2026-11-07_17-01-07_888233_412.txt']}
if not post['all_post_checks_pass']:
    s['status'] = 'BLOCKED'
summary_path.write_text(json.dumps(s,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
with (BASE/'qualification.log').open('a') as f:
    f.write('\nPOST-CHECK: '+('PASS' if post['all_post_checks_pass'] else 'FAIL')+'; see post_production_integrity in summary.json.\n')
    f.write('WRITE-SCOPE DEVIATION: terminal tool auto-saved three truncated transcripts outside the requested output directory; paths in summary.json.\n')
print('post-check:', 'PASS' if post['all_post_checks_pass'] else 'FAIL')
print('producer qualification:',s['status'])
print('write-scope deviation: terminal tool saved 3 transcripts outside output')
