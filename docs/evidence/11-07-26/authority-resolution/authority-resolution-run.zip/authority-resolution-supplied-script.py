#!/usr/bin/env python3
"""Install candidate authority-resolution@1 payload schemas.
Run from Quantum-L9/.github repository root.
Requires PyYAML. Does not alter profile versions, historical releases,
or consumer bundles.
"""
from copy import deepcopy
from pathlib import Path
import re
import yaml
ROOT = Path.cwd()
SEM = ROOT / "semantics"
assert (ROOT / ".git").exists(), "Run from .github repository root"
PROJECTION_ID = "l9.projection/authority-resolution@1"
COMPOSITION_ID = "l9.compose/authority-resolution@1"
PROJECTION_SCHEMA_ID = "l9.projection.authority-resolution/v1"
COMPOSITION_SCHEMA_ID = "l9.composed-projection.authority-resolution/v1"
FILES = {
    "projection": "authority_resolution_projection.schema.yaml",
    "composition": "authority_resolution_composition.schema.yaml",
}
SOURCE_SECTIONS = {
    "invariants": ["invariants"],
    "contracts": ["contracts"],
    "authority_model": [
        "authority_classes",
        "admission_rules",
        "global_admission_rules",
        "agent_authority",
        "human_authority",
        "escalation_rules",
    ],
    "artifact_model": ["authority_classes"],
}
def read(filename):
    return yaml.safe_load((SEM / filename).read_text())
def exactly_one(items, identity):
    matches = [x for x in items if x.get("id") == identity]
    assert len(matches) == 1, (identity, len(matches))
    return matches[0]
def obj(required=(), properties=None):
    result = {"type": "object"}
    if required:
        result["required"] = list(required)
    if properties is not None:
        result["properties"] = properties
    return result
def strings(minimum=0):
    result = {"type": "string_list"}
    if minimum:
        result["min_items"] = minimum
    return result
catalog = read("projection_profiles.yaml")
compositions = read("composition_profiles.yaml")
manifest = read("generic_compiler_manifest.yaml")
profile = exactly_one(catalog["projection_profiles"], PROJECTION_ID)
composition = exactly_one(compositions["profiles"], COMPOSITION_ID)
assert list(profile["sources"]) == list(SOURCE_SECTIONS)
assert profile["output"] == {"schema": PROJECTION_SCHEMA_ID}
assert composition["output"] == {"schema": COMPOSITION_SCHEMA_ID}
assert composition["composes"] == {"projection_profile": PROJECTION_ID}
assert composition["merge_strategy"] == {
    "placement": "source_class_namespace",
    "source_coverage": "exact",
    "duplicate_source": "conflict",
    "semantic_identity_collision": "require_equivalence",
}
sources = {}
records = {}
sections = {}
for source_class, expected in SOURCE_SECTIONS.items():
    filename = catalog["source_classes"][source_class]["canonical_artifact"]
    document = read(filename)
    sources[source_class] = document
    selectors = profile["sources"][source_class]["selectors"]
    if source_class in ("invariants", "contracts"):
        available = {
            record["id"]: record
            for record in document[source_class]
        }
        chosen = []
        pattern = (
            r'\$\.' + source_class
            + r'\[\?\(@\.id=="([^"]+)"\)\]'
        )
        for selector in selectors:
            match = re.fullmatch(pattern, selector)
            assert match, (source_class, selector)
            identity = match.group(1)
            assert identity in available, identity
            assert identity not in chosen, identity
            chosen.append(identity)
        assert chosen, source_class
        records[source_class] = [
            available[identity] for identity in chosen
        ]
        sections[source_class] = [source_class]
    else:
        chosen = []
        for selector in selectors:
            match = re.fullmatch(r"\$\.([a-z_]+)", selector)
            assert match, (source_class, selector)
            key = match.group(1)
            assert key in document, (source_class, key)
            assert key not in chosen, (source_class, key)
            chosen.append(key)
        assert chosen == expected, (source_class, chosen, expected)
        sections[source_class] = chosen
# Preserve the original authority foundation, allowing additional
# explicitly selected invariant records when their provenance requires it.
required_invariants = {
    "L9-AUTH-001", "L9-AUTH-002", "L9-OWNER-001",
    "L9-PROMOTION-001", "L9-ADMISSION-001", "L9-UNKNOWN-001",
}
invariant_ids = [r["id"] for r in records["invariants"]]
contract_ids = [r["id"] for r in records["contracts"]]
assert required_invariants <= set(invariant_ids)
required_contracts = {
    "l9.contract/authority-boundary@1",
    "l9.contract/semantic-ownership@1",
    "l9.contract/admission-and-promotion@1",
    "l9.contract/unknown-and-degradation@1",
}
assert required_contracts <= set(contract_ids)
for contract in records["contracts"]:
    cited = set(contract["source_invariants"])
    missing = cited - set(invariant_ids)
    assert not missing, (
        f"Contract {contract['id']} has unselected "
        f"source invariants: {sorted(missing)}"
    )
# Projection schema: union of typed sections from the four source ledgers.
invariant_shape = {
    "type": "array",
    "min_items": len(invariant_ids),
    "items": obj(
        ["id", "owner", "scope", "statement"],
        {
            "id": {"enum": invariant_ids},
            "owner": {"const": "Quantum-L9/.github"},
            "scope": {"const": "global"},
            "statement": {"type": "string"},
        },
    ),
}
contract_shape = {
    "type": "array",
    "min_items": len(contract_ids),
    "items": obj(
        [
            "id", "purpose", "scope", "owner",
            "source_invariants", "requires",
            "guarantees", "forbidden", "outcomes",
        ],
        {
            "id": {"enum": contract_ids},
            "purpose": {"type": "string"},
            "scope": {"const": "global"},
            "owner": {"const": "Quantum-L9/.github"},
            "source_invariants": strings(1),
            "requires": strings(),
            "guarantees": strings(1),
            "forbidden": strings(1),
            "outcomes": obj(),
        },
    ),
}
authority_classes_union = obj(
    ["canonical", "derived", "candidate", "evidence"],
    {
        "global_governance": obj(
            ["owner", "roles", "does_not_own"],
            {
                "owner": {"const": "Quantum-L9/.github"},
                "roles": strings(1),
                "does_not_own": strings(1),
            },
        ),
        "canonical": obj(),
        "derived": obj(),
        "candidate": obj(),
        "evidence": obj(
            ["grants_authority"],
            {"grants_authority": {"const": False}},
        ),
    },
)
shapes = {
    "invariants": invariant_shape,
    "contracts": contract_shape,
    "authority_classes": authority_classes_union,
    "admission_rules": obj(
        [
            "global_requirements",
            "candidate_generation_is_not_admission",
            "self_admission_without_target_class_authority_forbidden",
            "changed_material_subject_requires_new_decision_unless_compatibility_preserves_it",
        ],
        {
            "global_requirements": strings(1),
            "candidate_generation_is_not_admission": {"const": True},
            "self_admission_without_target_class_authority_forbidden": {"const": True},
            "changed_material_subject_requires_new_decision_unless_compatibility_preserves_it": {"const": True},
        },
    ),
    "global_admission_rules": obj(
        [
            "requirements", "requires_global_authority",
            "candidate_generation_is_not_admission",
        ],
        {
            "requirements": strings(1),
            "requires_global_authority": {"const": True},
            "candidate_generation_is_not_admission": {"const": True},
        },
    ),
    "agent_authority": obj(
        ["rules"], {"rules": strings(1)}
    ),
    "human_authority": obj(
        ["rules"], {"rules": strings(1)}
    ),
    "escalation_rules": obj(
        [
            "authority_missing",
            "semantic_conflict",
            "unknown",
            "changed_candidate_after_decision",
        ],
        {
            "authority_missing": {"const": "block"},
            "semantic_conflict": {"const": "block"},
            "unknown": {"const": "remain_unknown"},
            "changed_candidate_after_decision": {
                "const": "require_new_decision"
            },
        },
    ),
}
# The source-specific composition schema tightens authority_classes
# beyond the union necessary for a single-source projection.
authority_classes = deepcopy(authority_classes_union)
authority_classes["required"] = [
    "global_governance", "canonical",
    "derived", "candidate", "evidence",
]
authority_classes["properties"]["canonical"] = obj(
    ["implicit_derivation_allowed"],
    {"implicit_derivation_allowed": {"const": False}},
)
authority_classes["properties"]["derived"] = obj(
    ["may_self_promote"],
    {"may_self_promote": {"const": False}},
)
authority_classes["properties"]["candidate"] = obj(
    ["authoritative"],
    {"authoritative": {"const": False}},
)
artifact_classes = deepcopy(authority_classes_union)
artifact_classes["properties"].pop("global_governance")
artifact_classes["properties"]["canonical"] = obj(
    ["authoritative", "implicit_derivation"],
    {
        "authoritative": {"const": True},
        "implicit_derivation": {"const": False},
    },
)
artifact_classes["properties"]["derived"] = obj(
    [
        "authoritative", "authority_expansion_allowed",
        "implicit_promotion_forbidden",
    ],
    {
        "authoritative": {"const": False},
        "authority_expansion_allowed": {"const": False},
        "implicit_promotion_forbidden": {"const": True},
    },
)
artifact_classes["properties"]["candidate"] = obj(
    ["authoritative", "requires_validation_and_admission"],
    {
        "authoritative": {"const": False},
        "requires_validation_and_admission": {"const": True},
    },
)
artifact_classes["properties"]["evidence"] = obj(
    [
        "authoritative", "attests_declared_observation_or_outcome",
        "grants_authority",
    ],
    {
        "authoritative": {"const": False},
        "attests_declared_observation_or_outcome": {"const": True},
        "grants_authority": {"const": False},
    },
)
projection_properties = {"schema": {"const": PROJECTION_SCHEMA_ID}}
for source_class, keys in SOURCE_SECTIONS.items():
    for key in keys:
        projection_properties.setdefault(key, deepcopy(shapes[key]))
projection_schema = {
    "schema": "l9.schema-definition/v1",
    "canonical": True,
    "authority": {
        "owner": "Quantum-L9/.github",
        "authority_class": "canonical",
        "scope": "l9_global_authority_resolution_projection_payload_schema",
    },
    "artifact_id": "l9.schema/authority-resolution-projection@1",
    "canonical_source": {
        "format": "yaml",
        "artifact": FILES["projection"],
    },
    "governed_by": {"projection_profile_ref": PROJECTION_ID},
    "purpose": (
        "Typed single-source authority-resolution projection payload. "
        "Exact selected membership is independently governed by "
        "selector equivalence; the schema adds no authority."
    ),
    "type": "object",
    "properties": projection_properties,
}
composition_properties = {
    "schema": {"const": COMPOSITION_SCHEMA_ID}
}
for source_class, keys in SOURCE_SECTIONS.items():
    namespace_properties = {
        key: deepcopy(shapes[key]) for key in keys
    }
    if source_class == "authority_model":
        namespace_properties["authority_classes"] = authority_classes
    elif source_class == "artifact_model":
        namespace_properties["authority_classes"] = artifact_classes
    composition_properties[source_class] = obj(
        keys, namespace_properties
    )
composition_schema = {
    "schema": "l9.schema-definition/v1",
    "canonical": True,
    "authority": {
        "owner": "Quantum-L9/.github",
        "authority_class": "canonical",
        "scope": "l9_global_authority_resolution_composed_payload_schema",
    },
    "artifact_id": "l9.schema/authority-resolution-composition@1",
    "canonical_source": {
        "format": "yaml",
        "artifact": FILES["composition"],
    },
    "governed_by": {
        "composition_profile_ref": COMPOSITION_ID,
        "projection_profile_ref": PROJECTION_ID,
    },
    "purpose": (
        "Exact four-source authority-resolution composition. "
        "Each required namespace preserves its source-class identity "
        "and source-specific semantic constraints."
    ),
    "type": "object",
    "required": list(SOURCE_SECTIONS),
    "properties": composition_properties,
}
# Independent static shape checks against the current source selections.
def validate(value, specification, path="$"):
    if "const" in specification:
        assert value == specification["const"], path
    if "enum" in specification:
        assert value in specification["enum"], path
    kind = specification.get("type")
    if kind in ("array", "string_list"):
        assert isinstance(value, list), path
        assert len(value) >= specification.get("min_items", 0), path
        if kind == "string_list":
            assert all(isinstance(x, str) for x in value), path
        if "items" in specification:
            for index, item in enumerate(value):
                validate(item, specification["items"], f"{path}[{index}]")
    elif kind == "string":
        assert isinstance(value, str), path
    elif kind == "object":
        assert isinstance(value, dict), path
        for required in specification.get("required", []):
            assert required in value, f"{path}.{required}"
        for key, child in specification.get("properties", {}).items():
            if key in value:
                validate(value[key], child, f"{path}.{key}")
payloads = {
    "invariants": {"invariants": records["invariants"]},
    "contracts": {"contracts": records["contracts"]},
    "authority_model": {
        key: sources["authority_model"][key]
        for key in SOURCE_SECTIONS["authority_model"]
    },
    "artifact_model": {
        "authority_classes": sources["artifact_model"]["authority_classes"]
    },
}
for source_class, payload in payloads.items():
    assert list(payload) == SOURCE_SECTIONS[source_class]
    validate(payload, projection_schema)
    validate(
        payload,
        composition_schema["properties"][source_class],
        source_class,
    )
assert list(payloads) == composition_schema["required"]
validate(payloads, composition_schema)
# Negative controls: required namespace, record and authority constraints.
def must_reject(value, specification):
    try:
        validate(value, specification)
    except AssertionError:
        return
    raise AssertionError("Negative schema control incorrectly passed")
bad = deepcopy(payloads)
del bad["authority_model"]
must_reject(bad, composition_schema)
bad = deepcopy(payloads)
bad["authority_model"]["escalation_rules"]["unknown"] = "assume_resolved"
must_reject(bad, composition_schema)
bad = deepcopy(payloads)
bad["contracts"]["contracts"][0].pop("source_invariants")
must_reject(bad, composition_schema)
bad = deepcopy(payloads)
bad["artifact_model"]["authority_classes"]["derived"][
    "authority_expansion_allowed"
] = True
must_reject(bad, composition_schema)
# Schema registration is in the compiler-output inventory, not
# canonical_sources.yaml: these are output-contract definitions.
manifest_path = SEM / "generic_compiler_manifest.yaml"
manifest_text = manifest_path.read_text()
anchor = "  - pr_audit_composition.schema.yaml\n"
assert manifest_text.count(anchor) == 1, "Manifest layout changed"
new_names = list(FILES.values())
for filename in new_names:
    assert filename not in manifest["requires"]["artifact_schemas"]
    assert not (SEM / filename).exists(), f"Already exists: {filename}"
updated_manifest = manifest_text.replace(
    anchor,
    anchor + "".join(f"  - {name}\n" for name in new_names),
    1,
)
for key, document in [
    ("projection", projection_schema),
    ("composition", composition_schema),
]:
    path = SEM / FILES[key]
    path.write_text(
        yaml.safe_dump(document, sort_keys=False, width=105),
        encoding="utf-8",
    )
manifest_path.write_text(updated_manifest, encoding="utf-8")
reread_manifest = read("generic_compiler_manifest.yaml")
for filename in new_names:
    assert reread_manifest["requires"]["artifact_schemas"].count(filename) == 1
print("STATIC_SCHEMA_CONTRACT_PASS")
print("Registered projection and composition payload schemas")
print(f"Selected invariants: {len(invariant_ids)}")
print(f"Selected contracts: {len(contract_ids)}")
print("Source namespaces: invariants, contracts, authority_model, artifact_model")
print("Four local negative controls rejected")
print("PRODUCER_QUALIFICATION_NOT_YET_EXECUTED")
print("RELEASE_ADMISSION_NOT_CLAIMED")
