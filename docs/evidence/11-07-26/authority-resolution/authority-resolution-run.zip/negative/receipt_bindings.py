#!/usr/bin/env python3
"""Cross-check all five real receipts against their actual artifacts and resolved pins."""
import json
import sys
from pathlib import Path
from l9_semantic_compiler.engine.compiler import load_artifact_file
from l9_semantic_compiler.engine.registry import CanonicalAuthority
from l9_semantic_compiler.engine.receipts import validate_receipt_document
from l9_semantic_compiler.passes.projection import verify_projection_artifact, verify_composed_projection, result_from_criteria
from l9_semantic_compiler.passes.validate import schema_violations

R=Path(__file__).resolve().parent
REV='290bcd90378577392640cea9c6053c178423f0da'
a=CanonicalAuthority('/home/ubuntu/l9-projection-campaign/code-pr',REV,repository='Quantum-L9/.github')
coords=json.loads((R/'inputs/coordinates.json').read_text())
summary=json.loads((R/'summary.json').read_text())
receipt_schema=a.artifact_schema('l9.schema/compiler-receipt@1').document
by_ref={x['ref']:x['digest'] for x in coords['coordinates']['sources']}
components=[]; component_bindings={}; report={}
for name, control in summary['positive_controls'].items():
    if not name.startswith('projection:'): continue
    doc=load_artifact_file(control['artifact_path']); receipt=load_artifact_file(control['receipt_path'])
    component_ref=doc['projection_profile_ref']+'#'+doc['source_ref']
    validate_receipt_document(receipt,expected_subject_ref=component_ref)
    current=verify_projection_artifact(a,doc); result,unresolved=result_from_criteria(current['criteria'])
    expected_source={'ref':doc['source_ref'],'digest':by_ref[doc['source_ref']],
                     'revision':REV,'path':coords['source_paths'][doc['source_ref']]}
    checks={'receipt_schema_valid':schema_violations(receipt,receipt_schema)==[],
            'receipt_validator_succeeded':True, 'exact_source_input':receipt['inputs']==[expected_source],
            'projection_source_pin':doc['source_digest']==expected_source['digest'],
            'projection_profile_pin':receipt['profile']==coords['coordinates']['projection_profile'] and doc['projection_profile_ref']==receipt['profile']['ref'] and doc['projection_profile_digest']==receipt['profile']['digest'],
            'output_binding':receipt['output']=={'ref':component_ref,'digest':doc['projection_digest']},
            'governing_authority':receipt['governing_coordinates']['repository']=='Quantum-L9/.github' and receipt['governing_coordinates']['revision']==REV,
            'receipt_and_reverification_pass':receipt['result']==result=='pass' and not unresolved}
    report[name]=checks; components.append(doc); component_bindings[doc['source_ref']]={'ref':component_ref,'digest':doc['projection_digest']}
c=summary['positive_controls']['composition']; doc=load_artifact_file(c['artifact_path']); receipt=load_artifact_file(c['receipt_path'])
validate_receipt_document(receipt,expected_subject_ref=receipt['output']['ref'])
verified=verify_composed_projection(a,doc,components); result,unresolved=result_from_criteria(verified['criteria'])
report['composition']={'receipt_schema_valid':schema_violations(receipt,receipt_schema)==[],
    'receipt_validator_succeeded':True, 'exact_component_inputs':receipt['inputs']==[component_bindings[x['ref']] for x in coords['coordinates']['sources']],
    'composition_profile_pin':receipt['profile']==doc['composition_profile']==coords['composition_profile'],
    'output_binding':receipt['output']['digest']==doc['composition_digest'],
    'governing_authority':receipt['governing_coordinates']['repository']=='Quantum-L9/.github' and receipt['governing_coordinates']['revision']==REV,
    'receipt_and_reverification_pass':receipt['result']==result=='pass' and not unresolved}
passed=all(all(checks.values()) for checks in report.values())
(R/'logs/receipt-bindings.json').write_text(json.dumps({'status':'PASS' if passed else 'FAIL','checks':report},indent=2,sort_keys=True)+'\n')
print('Receipt bindings:', 'PASS' if passed else 'FAIL', json.dumps(report,sort_keys=True))
sys.exit(0 if passed else 1)
