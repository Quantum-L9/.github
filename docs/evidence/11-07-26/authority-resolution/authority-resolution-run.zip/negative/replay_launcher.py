#!/usr/bin/env python3
"""Repeat in a separate scratch tree; preserve first originals and capture return code."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
replay = root / 'replay'
replay.mkdir(exist_ok=False)
shutil.copyfile(root / 'qualify.py', replay / 'qualify.py')
first_paths = json.loads((root / 'outputs' / 'original-sha256-before.json').read_text())
def hashes():
    return {p:'sha256:'+hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in first_paths}
before = hashes()
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1',
       'PYTHONPATH':'/tmp/l9-projection-qa.nBKv8FWo/compiler/src',
       'GIT_OPTIONAL_LOCKS':'0', 'TMPDIR':str(root/'outputs')}
result = subprocess.run(['/tmp/l9-projection-qa.nBKv8FWo/venv/bin/python', str(replay/'qualify.py')],
                        cwd=replay, env=env, capture_output=True, text=True)
(root/'logs'/'replay.log').write_text(result.stdout + result.stderr)
(root/'logs'/'replay-exit-code.txt').write_text(str(result.returncode)+'\n')
after = hashes()
(root/'logs'/'replay-launcher-result.json').write_text(json.dumps({
    'returncode':result.returncode,'first_originals_match_first_run':before==first_paths,
    'first_originals_unchanged_by_replay':before==after,
    'replay_summary':str(replay/'summary.json')},indent=2,sort_keys=True)+'\n')
print('REPLAY exit=',result.returncode,'first_originals_match_first_run=',before==first_paths,
      'first_originals_unchanged_by_replay=',before==after)
print(result.stdout)
if result.stderr: print('STDERR:',result.stderr)
