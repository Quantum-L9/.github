#!/usr/bin/env python3
"""Read-only authority/producer qualification at exact commits; all writes below this directory.

Run with the QA venv and PYTHONDONTWRITEBYTECODE=1, with compiler/src on PYTHONPATH.
A succeeded execution or a valid-but-unknown receipt is NOT a PASS positive control.
Negative operations are still exercised diagnostically, but cannot be qualified unless
all five producer receipt positive controls have result=pass.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import traceback
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import l9_semantic_compiler
from l9_semantic_compiler.engine.compiler import (SemanticCompiler, ProjectionRequest,
    CompositionRequest, load_artifact_file)
from l9_semantic_compiler.engine.errors import SemanticCompilerError
from l9_semantic_compiler.engine.registry import CanonicalAuthority
from l9_semantic_compiler.engine.receipts import validate_receipt_document
from l9_semantic_compiler.passes.projection import (projection_coordinates, envelope_digest,
    verify_projection_artifact, verify_composed_projection, result_from_criteria)
from l9_semantic_compiler.passes.validate import schema_violations

ROOT = Path(__file__).resolve().parent
AUTH = Path('/home/ubuntu/l9-projection-campaign/code-pr')
QA = Path('/tmp/l9-projection-qa.nBKv8FWo')
COMP = QA / 'compiler'
REV = '290bcd90378577392640cea9c6053c178423f0da'
CREV = '943db9a462d35ba66771a700ece77c746295f591'
PROJ = 'l9.projection/authority-resolution@1'
COMPOSE = 'l9.compose/authority-resolution@1'
REPO = 'Quantum-L9/.github'
CASES = {
    '01_missing_source_pin': ('INVALID_REQUEST', None),
    '02_wrong_profile_digest': ('REVISION_MISMATCH', 'profile_digest'),
    '03_payload_without_redigest': ('REVISION_MISMATCH', 'projection_digest'),
    '04_payload_with_producer_redigest': ('SEMANTIC_DIVERGENCE', 'selection_equivalence'),
    '05_missing_source_component': ('INVALID_REQUEST', 'source_coverage'),
    '06_duplicate_component': ('AMBIGUOUS_SEMANTICS', 'duplicate_source'),
    '07_wrong_composition_pin': ('REVISION_MISMATCH', 'composition_profile_digest'),
    '08_receipt_tamper_without_redigest': ('INVALID_REQUEST', None),
    '09_omitted_namespace_redigested_verify': ('SEMANTIC_DIVERGENCE', 'composition_equivalence'),
    '10_missing_namespace_direct_schema': ('SCHEMA_VIOLATION', '$.artifact_model: required field missing'),
}


def now(): return datetime.now(timezone.utc).isoformat()
def dump(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False, default=str) + '\n', encoding='utf-8')
def sha(path): return 'sha256:' + hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], check=True, capture_output=True,
                          env={**os.environ, 'GIT_OPTIONAL_LOCKS':'0'}).stdout

def snapshot(root):
    head = git(root, 'rev-parse', 'HEAD').decode().strip()
    status = git(root, 'status', '--porcelain=v1', '--untracked-files=all').decode()
    names = git(root, 'ls-files', '-z').split(b'\0')
    files = {}
    for raw in names:
        if not raw: continue
        rel = os.fsdecode(raw); p = root / rel
        if p.is_symlink(): files[rel] = 'symlink:' + os.readlink(p)
        elif p.is_file(): files[rel] = sha(p)
        else: files[rel] = 'missing-or-special'
    return {'root': str(root), 'head': head, 'status': status, 'tracked_file_sha256': files}

def wrong(digest):
    assert digest.startswith('sha256:') and len(digest) == 71
    return digest[:-1] + ('0' if digest[-1] != '0' else '1')

def exc_info(e):
    return {'type': type(e).__name__, 'code': getattr(e, 'code', None),
            'typed_ref': getattr(e, 'typed_ref', None), 'message': str(e),
            'criterion': getattr(e, 'diagnostics', {}).get('criterion'),
            'diagnostics': getattr(e, 'diagnostics', {}),
            'first_divergence': getattr(e, 'first_divergence', None),
            'traceback': traceback.format_exc()}


def main():
    results = {'started_utc': now(), 'authority_revision': REV, 'compiler_revision': CREV,
               'scope': 'actual pinned producer only; no independent candidate-consumer binding or historical staleness claim',
               'positive_controls': {}, 'cases': {}, 'errors': []}
    before = {}
    emission_paths = []
    try:
        assert sys.prefix == str(QA / 'venv'), (sys.prefix, str(QA / 'venv'))
        assert Path(l9_semantic_compiler.__file__).resolve().is_relative_to((COMP / 'src').resolve()), l9_semantic_compiler.__file__
        for label, root, rev in [('authority', AUTH, REV), ('compiler', COMP, CREV)]:
            before[label] = snapshot(root)
            assert before[label]['head'] == rev, before[label]['head']
            assert not before[label]['status'], (label, before[label]['status'])
            dump(ROOT / 'logs' / (label + '-before.json'), before[label])
        results['python'] = sys.executable
        results['producer_module'] = l9_semantic_compiler.__file__
        results['producer_version'] = SemanticCompiler.version
        print('Revisions and checkout state verified', flush=True)

        authority = CanonicalAuthority(AUTH, REV, repository=REPO)
        coordinates = projection_coordinates(authority, PROJ)
        resolved = authority.resolve_profile(PROJ)
        comp_resolved = authority.resolve_profile(COMPOSE)
        comp_pin = {'ref': comp_resolved.ref, 'digest': comp_resolved.digest}
        classes = list(resolved.record['sources'])
        assert classes == ['invariants', 'contracts', 'authority_model', 'artifact_model'], classes
        source_map = {authority.resolve_source(resolved.catalog, c).ref: c for c in classes}
        assert len(coordinates['sources']) == len(source_map) == 4
        details = {'coordinates': coordinates, 'composition_profile': comp_pin, 'source_class_by_ref': source_map,
                   'source_paths': {ref: authority.resolve_source(resolved.catalog, cls).document.path
                                    for ref, cls in source_map.items()}}
        dump(ROOT / 'inputs' / 'coordinates.json', details)
        input_paths = set(details['source_paths'].values()) | {
            'semantics/projection_profiles.yaml', 'semantics/composition_profiles.yaml',
            'semantics/canonical_sources.yaml', 'semantics/generic_compiler_manifest.yaml',
            'semantics/authority_resolution_projection.schema.yaml',
            'semantics/authority_resolution_composition.schema.yaml'}
        for rel in sorted(input_paths):
            source = AUTH / rel
            dest = ROOT / 'inputs' / 'authority-snapshot' / rel
            dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, dest)
        dump(ROOT / 'inputs' / 'input-sha256.json', {rel: sha(AUTH / rel) for rel in sorted(input_paths)})
        authority_spec = {'repository': REPO, 'root': str(AUTH), 'revision': REV}
        req = {'schema': 'l9.semantic-projection-request/v1', 'authority': authority_spec,
               'projection_profile': copy.deepcopy(coordinates['projection_profile']),
               'sources': copy.deepcopy(coordinates['sources']), 'output_root': str(ROOT / 'outputs' / 'projections')}
        dump(ROOT / 'inputs' / 'positive-projection-request.json', req)
        compiler = SemanticCompiler()
        projected = compiler.project(ProjectionRequest.from_dict(req))
        assert len(projected.artifacts) == 4, len(projected.artifacts)
        components = [load_artifact_file(a.path) for a in projected.artifacts]
        component_paths = [str(a.path) for a in projected.artifacts]
        emission_paths.extend(Path(x) for a in projected.artifacts for x in (a.path, a.receipt_path))
        by_ref = {c['source_ref']: c for c in components}
        assert set(by_ref) == set(source_map)
        for art, doc in zip(projected.artifacts, components):
            receipt = load_artifact_file(art.receipt_path)
            validate_receipt_document(receipt, expected_subject_ref=art.ref)
            report = verify_projection_artifact(authority, doc)
            calc_result, unresolved = result_from_criteria(report['criteria'])
            checks = {'producer_operation_succeeded': projected.status == 'succeeded',
                      'receipt_digest_subject_valid': True,
                      'receipt_binds_output': receipt['output']['ref'] == art.ref and receipt['output']['digest'] == art.digest,
                      'receipt_binds_authority_revision': receipt['inputs'][0]['revision'] == REV,
                      'actual_payload_schema_pass': report['criteria']['payload_schema']['status'] == 'pass',
                      'producer_and_receipt_and_reverification_result_PASS': art.result == receipt['result'] == calc_result == 'pass',
                      'no_unresolved_criteria': not unresolved}
            key = 'projection:' + source_map[doc['source_ref']]
            results['positive_controls'][key] = {'status':'PASS' if all(checks.values()) else 'FAIL',
                'producer_status': projected.status, 'result': art.result, 'receipt_result': receipt['result'],
                'verification_result': calc_result, 'unresolved_criteria': unresolved, 'checks': checks,
                'artifact_path': str(art.path), 'receipt_path': str(art.receipt_path)}
        print('Projection receipts:', ', '.join(k+'='+v['result'] for k,v in results['positive_controls'].items()), flush=True)

        compose_req = {'schema':'l9.semantic-composition-request/v1', 'authority':authority_spec,
                       'composition_profile':comp_pin, 'components':component_paths,
                       'output_root':str(ROOT / 'outputs' / 'composition')}
        dump(ROOT / 'inputs' / 'positive-composition-request.json', compose_req)
        composed_result = compiler.compose(CompositionRequest.from_dict(compose_req))
        assert len(composed_result.artifacts) == 1
        cart = composed_result.artifacts[0]
        cdoc = load_artifact_file(cart.path); creceipt = load_artifact_file(cart.receipt_path)
        emission_paths.extend([Path(cart.path), Path(cart.receipt_path)])
        validate_receipt_document(creceipt, expected_subject_ref=cart.ref)
        creport = verify_composed_projection(authority, cdoc, components)
        cverify, cunresolved = result_from_criteria(creport['criteria'])
        cchecks = {'producer_operation_succeeded': composed_result.status == 'succeeded',
                   'receipt_digest_subject_valid':True,
                   'receipt_binds_output':creceipt['output']['ref'] == cart.ref and creceipt['output']['digest'] == cart.digest,
                   'exact_four_namespaces':set(cdoc['payload']) == set(classes),
                   'four_component_inputs':len(creceipt['inputs']) == 4 and len(cdoc['components']) == 4,
                   'actual_payload_schema_pass':creport['criteria']['payload_schema']['status'] == 'pass',
                   'producer_and_receipt_and_reverification_result_PASS': cart.result == creceipt['result'] == cverify == 'pass',
                   'no_unresolved_criteria': not cunresolved}
        results['positive_controls']['composition'] = {'status':'PASS' if all(cchecks.values()) else 'FAIL',
            'producer_status':composed_result.status, 'result':cart.result, 'receipt_result':creceipt['result'],
            'verification_result':cverify, 'unresolved_criteria':cunresolved, 'checks':cchecks,
            'artifact_path':str(cart.path), 'receipt_path':str(cart.receipt_path)}
        all_positive_pass = all(v['status'] == 'PASS' for v in results['positive_controls'].values())
        results['positive_gate_passed'] = all_positive_pass
        print('Composition receipt:', cart.result, 'strict five-control PASS gate:', all_positive_pass, flush=True)
        original_hashes = {str(p): sha(p) for p in emission_paths}
        dump(ROOT / 'outputs' / 'original-sha256-before.json', original_hashes)

        # Case result is BLOCKED by the positive gate, even when a diagnostic exception matches.
        def negative(case, invoke, extra_check, context):
            code, criterion = CASES[case]
            item = {'expected':{'code':code,'criterion':criterion}, 'context':context}
            try:
                got = invoke()
                item['observed'] = {'type':'NO_EXCEPTION','returned':repr(got)}
                item['diagnostic_checks'] = {'typed_exception':False}
            except SemanticCompilerError as exc:
                item['observed'] = exc_info(exc)
                checks = {'typed_code':exc.code == code,
                          'typed_ref':exc.typed_ref == 'l9.semantic-compiler.error/' + code,
                          'criterion':exc.diagnostics.get('criterion') == criterion}
                try: checks.update(extra_check(exc))
                except Exception as check_exc: checks['check_exception'] = False; item['check_error'] = exc_info(check_exc)
                item['diagnostic_checks'] = checks
            except Exception as exc:
                item['observed'] = exc_info(exc); item['diagnostic_checks'] = {'typed_exception':False}
            item['expected_typed_rejection_matches'] = all(item['diagnostic_checks'].values())
            item['status'] = ('PASS' if item['expected_typed_rejection_matches'] else 'FAIL') if all_positive_pass else 'BLOCKED'
            if not all_positive_pass: item['gate_reason'] = 'Producer positive receipts are not all PASS; raw diagnostic observations are not qualified negative controls.'
            results['cases'][case] = item; dump(ROOT / 'cases' / (case + '.json'), item)
            print(case, item['status'], 'diagnostic_match=', item['expected_typed_rejection_matches'],
                  'observed=', item['observed'].get('code'), '/', item['observed'].get('criterion'), flush=True)

        def project(request): return compiler.project(ProjectionRequest.from_dict(request))
        def compose(request): return compiler.compose(CompositionRequest.from_dict(request))
        def save_request(case, request): dump(ROOT / 'inputs' / (case + '-request.json'), request)
        def saved_copy(case, obj):
            path = ROOT / 'inputs' / (case + '.json'); dump(path,obj); return path
        source = coordinates['sources'][0]
        original = components[0]; original_path = component_paths[0]
        assert original['source_ref'] == source['ref']
        other_paths = component_paths[1:]

        mreq=copy.deepcopy(req); mreq['sources']=mreq['sources'][1:]; mreq['output_root']=str(ROOT/'outputs'/'negative-missing-pin'); save_request('01_missing_source_pin',mreq)
        negative('01_missing_source_pin', lambda:project(mreq), lambda e:{
            'exactly_one_real_pin_missing':set(e.diagnostics.get('declared',[]))-set(e.diagnostics.get('pinned',[]))=={source['ref']},
            'no_extra_pins':set(e.diagnostics.get('pinned',[])) <= set(e.diagnostics.get('declared',[])),
            'canonical_source_file_exists':(AUTH/details['source_paths'][source['ref']]).is_file()},
            {'removed_pin':source,'source_path':details['source_paths'][source['ref']]})

        preq=copy.deepcopy(req); preq['projection_profile']['digest']=wrong(req['projection_profile']['digest']); preq['output_root']=str(ROOT/'outputs'/'negative-profile'); save_request('02_wrong_profile_digest',preq)
        negative('02_wrong_profile_digest', lambda:project(preq), lambda e:{
            'ref':e.diagnostics.get('ref')==PROJ,'supplied_bad_digest':e.diagnostics.get('expected_digest')==preq['projection_profile']['digest'],
            'current_digest':e.diagnostics.get('observed_digest')==req['projection_profile']['digest']}, {'request':str(ROOT/'inputs'/'02_wrong_profile_digest-request.json')})

        for case, redigest in [('03_payload_without_redigest',False),('04_payload_with_producer_redigest',True)]:
            altered=copy.deepcopy(original); altered['payload']['__negative_control__']='changed copy only'
            computed=envelope_digest(altered,'projection_digest')
            if redigest: altered['projection_digest']=computed
            path=saved_copy(case,altered); r=copy.deepcopy(compose_req); r['components']=[str(path),*other_paths]; r['output_root']=str(ROOT/'outputs'/case); save_request(case,r)
            if not redigest:
                checks=lambda e,alt=altered,calc=computed:{'retained_original_digest':alt['projection_digest']==original['projection_digest'],
                    'producer_recomputed_digest_differs':calc!=alt['projection_digest'],
                    'reported_expected_recomputed':e.diagnostics.get('expected_digest')==calc,
                    'reported_observed_original':e.diagnostics.get('observed_digest')==original['projection_digest']}
            else:
                checks=lambda e,alt=altered:{'real_producer_redigest':alt['projection_digest']==envelope_digest(alt,'projection_digest'),
                    'digest_changed':alt['projection_digest']!=original['projection_digest'],
                    'correct_source_ref':e.diagnostics.get('source_ref')==original['source_ref'],
                    'divergence_identified':e.first_divergence is not None}
            negative(case,lambda r=r:compose(r),checks,{'original':original_path,'altered_copy':str(path),'computed_digest':computed,
                     'redigest_function':'l9_semantic_compiler.passes.projection.envelope_digest' if redigest else 'computed but not written'})

        miss=copy.deepcopy(compose_req); miss['components']=other_paths; miss['output_root']=str(ROOT/'outputs'/'05_missing'); save_request('05_missing_source_component',miss)
        negative('05_missing_source_component',lambda:compose(miss),lambda e:{'exact_missing_source_class':e.diagnostics.get('missing_source_classes')==[source_map[original['source_ref']]]},
                 {'omitted_component':original_path,'source_class':source_map[original['source_ref']]})
        dup=copy.deepcopy(compose_req); dup['components']=[*component_paths,component_paths[0]]; dup['output_root']=str(ROOT/'outputs'/'06_duplicate'); save_request('06_duplicate_component',dup)
        negative('06_duplicate_component',lambda:compose(dup),lambda e:{'exact_duplicate_ref':e.diagnostics.get('projection_refs')==[projected.artifacts[0].ref]},
                 {'duplicated_component':original_path})
        cp=copy.deepcopy(compose_req); cp['composition_profile']['digest']=wrong(comp_pin['digest']); cp['output_root']=str(ROOT/'outputs'/'07_bad_pin'); save_request('07_wrong_composition_pin',cp)
        negative('07_wrong_composition_pin',lambda:compose(cp),lambda e:{'ref':e.diagnostics.get('ref')==COMPOSE,
            'supplied_bad_digest':e.diagnostics.get('expected_digest')==cp['composition_profile']['digest'],
            'current_digest':e.diagnostics.get('observed_digest')==comp_pin['digest']}, {'request':str(ROOT/'inputs'/'07_wrong_composition_pin-request.json')})
        orig_receipt=load_artifact_file(projected.artifacts[0].receipt_path); altered_receipt=copy.deepcopy(orig_receipt)
        altered_receipt['claim']+=' [tampered copy]'; receipt_path=saved_copy('08_receipt_tamper_without_redigest',altered_receipt)
        negative('08_receipt_tamper_without_redigest',lambda:validate_receipt_document(load_artifact_file(receipt_path),expected_subject_ref=projected.artifacts[0].ref),
            lambda e:{'message':str(e)=='prior compilation receipt digest mismatch',
                'unchanged_receipt_digest':altered_receipt['receipt_digest']==orig_receipt['receipt_digest'],
                'reported_original_digest':e.diagnostics.get('observed_digest')==orig_receipt['receipt_digest'],
                'computed_digest_differs':e.diagnostics.get('expected_digest')!=orig_receipt['receipt_digest'],
                'result_unchanged':altered_receipt['result']==orig_receipt['result']},
            {'original':str(projected.artifacts[0].receipt_path),'copy':str(receipt_path),'method':'producer validate_receipt_document; not an independent consumer'})
        omitted=copy.deepcopy(cdoc); del omitted['payload']['artifact_model']; omitted['composition_digest']=envelope_digest(omitted,'composition_digest')
        omit_path=saved_copy('09_omitted_namespace_redigested_verify',omitted)
        negative('09_omitted_namespace_redigested_verify',lambda:verify_composed_projection(authority,load_artifact_file(omit_path),components),
            lambda e:{'producer_redigest':omitted['composition_digest']==envelope_digest(omitted,'composition_digest'),
                'digest_changed':omitted['composition_digest']!=cdoc['composition_digest'],
                'namespace_absent':'artifact_model' not in omitted['payload'],
                'four_original_components_unchanged':omitted['components']==cdoc['components'] and len(components)==4,
                'divergence_identified':e.first_divergence is not None},
            {'copy':str(omit_path),'method':'verify_composed_projection(authority, redigested copy, all four genuine components)'})

        cschema=authority.schema_defining('l9.composed-projection.authority-resolution/v1').document
        good_violations=schema_violations(cdoc['payload'],cschema)
        violations=schema_violations(omitted['payload'],cschema)
        item={'expected':{'code':'SCHEMA_VIOLATION','criterion':'$.artifact_model: required field missing'},
              'observed':{'violations':violations,'valid_payload_violations':good_violations},
              'context':{'schema':'semantics/authority_resolution_composition.schema.yaml','payload_copy':str(omit_path),
                         'method':'pinned producer schema_violations on payload, not envelope'},
              'diagnostic_checks':{'valid_payload_has_no_violations':good_violations==[],
                  'exact_missing_field_violation':violations==['$.artifact_model: required field missing']}}
        item['expected_typed_rejection_matches']=all(item['diagnostic_checks'].values())
        item['status']=('PASS' if item['expected_typed_rejection_matches'] else 'FAIL') if all_positive_pass else 'BLOCKED'
        if not all_positive_pass: item['gate_reason']='Producer positive receipts are not all PASS; diagnostic observation is not a qualified negative control.'
        results['cases']['10_missing_namespace_direct_schema']=item; dump(ROOT/'cases'/'10_missing_namespace_direct_schema.json',item)
        print('10_missing_namespace_direct_schema',item['status'],'diagnostic_match=',item['expected_typed_rejection_matches'],'violations=',violations,flush=True)

        pschema=authority.schema_defining('l9.projection.authority-resolution/v1').document
        descriptor=pschema['properties']['contracts']['items']['properties']['source_invariants']
        assert descriptor == {'type':'string_list','min_items':1}, descriptor
        contract_doc=by_ref['l9.source/contracts@1']; bad_payload=copy.deepcopy(contract_doc['payload'])
        assert len(bad_payload['contracts'])>0 and bad_payload['contracts'][0]['source_invariants']
        bad_payload['contracts'][0]['source_invariants']=[]
        dump(ROOT/'inputs'/'11_empty_string_list_payload.json',bad_payload)
        direct_good=schema_violations(['valid-entry'],descriptor); direct_empty=schema_violations([],descriptor)
        full_good=schema_violations(contract_doc['payload'],pschema); full_empty=schema_violations(bad_payload,pschema)
        capability={'schema_path':'semantics/authority_resolution_projection.schema.yaml:properties.contracts.items.properties.source_invariants',
            'descriptor':descriptor,'valid_list_violations':direct_good,'empty_list_violations':direct_empty,
            'valid_full_payload_violations':full_good,'empty_full_payload_violations':full_empty,
            'expected':'min_items:1 rejects []','observed':'accepted []' if not direct_empty else 'rejected []',
            'status':'FAIL' if not direct_empty else 'PASS',
            'interpretation':'Known limitation of pinned schema_violations: min_items is checked only for declared type array, not string_list. This is not a passed negative control.',
            'source':'compiler/src/l9_semantic_compiler/passes/validate.py:171-174,225-228',
            'input_copy':str(ROOT/'inputs'/'11_empty_string_list_payload.json')}
        results['string_list_min_items_capability']=capability; dump(ROOT/'cases'/'11_string_list_min_items_capability.json',capability)
        print('String-list min_items capability:',capability['status'],capability['observed'],'direct=',direct_empty,'full=',full_empty,flush=True)
        after_hashes={str(p):sha(p) for p in emission_paths}
        dump(ROOT/'outputs'/'original-sha256-after.json',after_hashes)
        results['original_emissions_unchanged']=original_hashes==after_hashes
    except Exception as e:
        results['errors'].append(exc_info(e)); print('HARNESS ERROR',repr(e),flush=True)
        for name in CASES:
            if name not in results['cases']:
                item={'status':'BLOCKED','reason':'Setup or prerequisite failed: '+repr(e),'expected':{'code':CASES[name][0],'criterion':CASES[name][1]}}
                results['cases'][name]=item; dump(ROOT/'cases'/(name+'.json'),item)
    finally:
        after={}
        for label, root, rev in [('authority', AUTH, REV), ('compiler', COMP, CREV)]:
            try:
                after[label]=snapshot(root); dump(ROOT/'logs'/(label+'-after.json'),after[label])
            except Exception as e: results['errors'].append(exc_info(e))
        results['checkout_unchanged']={label: before.get(label)==after.get(label) if label in before and label in after else False for label in ['authority','compiler']}
        results['positive_counts']=dict(Counter(v['status'] for v in results['positive_controls'].values()))
        results['negative_counts']=dict(Counter(v['status'] for v in results['cases'].values()))
        results['diagnostic_match_count']=sum(v.get('expected_typed_rejection_matches') is True for v in results['cases'].values())
        results['diagnostic_mismatch_count']=sum(v.get('expected_typed_rejection_matches') is False for v in results['cases'].values())
        results['completed_utc']=now()
        dump(ROOT/'summary.json',results)
        print('COUNTS positive=',results['positive_counts'],'negative=',results['negative_counts'],
              'diagnostic_matches=',results['diagnostic_match_count'],'diagnostic_mismatches=',results['diagnostic_mismatch_count'],flush=True)
        print('INTEGRITY checkout=',results['checkout_unchanged'],'emissions=',results.get('original_emissions_unchanged'),flush=True)
        print('SUMMARY',ROOT/'summary.json',flush=True)
    return 0 if not results['errors'] and results.get('positive_gate_passed') and all(v['status']=='PASS' for v in results['cases'].values()) and results.get('string_list_min_items_capability',{}).get('status')=='PASS' and all(results['checkout_unchanged'].values()) and results.get('original_emissions_unchanged') else 1

if __name__=='__main__': sys.exit(main())
