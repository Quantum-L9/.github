#!/usr/bin/env bash
set -u
QA=$(cat /home/ubuntu/l9-projection-campaign/qa-root.txt)
BASE=020a94bea86e7c5c5e4107da7014ec259508f397
COMP=943db9a462d35ba66771a700ece77c746295f591
LOG=/home/ubuntu/l9-projection-campaign/baseline-independent-replay.log
PYTHONDONTWRITEBYTECODE=1 "$QA/venv/bin/python" \
  "$QA/consumer/tools/authority/produce_projection_bundle.py" \
  --profile l9.projection/architecture-intelligence@1 \
  --authority-root /home/ubuntu/l9-projection-campaign/repo \
  --authority-revision "$BASE" --compiler-revision "$COMP" \
  --compiler "$QA/venv/bin/l9-semantic-compiler" \
  --output "$QA/baseline" --check > "$LOG" 2>&1
RC=$?
printf 'Actual --check exit code: %s\n' "$RC" >> "$LOG"
cat "$LOG"
exit "$RC"
