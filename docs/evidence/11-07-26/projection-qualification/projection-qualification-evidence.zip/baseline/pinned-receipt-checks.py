#!/usr/bin/env python3
"""Run existing pinned consumer/producer checks on the baseline; no production or replay."""
import importlib.util
import json
import sys
from pathlib import Path

Q = Path('/tmp/l9-projection-qa.nBKv8FWo')
BUNDLE = Q / 'baseline'
CONSUMER = Q / 'consumer'
ROOT = Path('/home/ubuntu/l9-projection-campaign/verify-baseline-authority')
REV = '020a94bea86e7c5c5e4107da7014ec259508f397'
PRODUCER_REV = '943db9a462d35ba66771a700ece77c746295f591'
sys.path.insert(0, str(Q / 'compiler/src'))
from l9_semantic_compiler.engine.canonical import digest
from l9_semantic_compiler.engine.receipts import validate_receipt_document
from l9_semantic_compiler.engine.registry import CanonicalAuthority
from l9_semantic_compiler.engine import compiler as engine
from l9_semantic_compiler.passes.validate import schema_violations

spec = importlib.util.spec_from_file_location('gar_baseline_verifier', CONSUMER / 'skills/l9-global-architect/scripts/verify_architecture_intelligence.py')
gar = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gar)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_shape(doc, descriptor, label):
    errors = schema_violations(doc, descriptor)
    require(not errors, f'{label} producer schema violations: {errors}')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    binding = gar.load_binding(gar.DEFAULT_BINDING)
    bundle_result = gar.verify_bundle(BUNDLE, binding)
    lock = bundle_result['lock']
    require(lock['authority']['revision'] == REV, 'authority revision mismatch')
    require(lock['producer']['revision'] == PRODUCER_REV, 'producer revision mismatch')
    gar.verify_currentness(ROOT, REV, lock, binding)
    anchored = gar.core.verify_profile_bundle(ROOT, BUNDLE, REV, gar.profile_spec(binding))
    gar._composed_receipt(BUNDLE, lock, bundle_result['composed'], binding, anchored['tree'])
    gar.core._check_shape(bundle_result['composed'], anchored['tree'], 'semantics/composed_projection.schema.yaml', 'COMPOSED')
    print('consumer pinned-tree verification: PASS')
    print('consumer authority coordinates:', json.dumps(anchored['coordinates'], sort_keys=True))
    print('consumer verified source components:', len(anchored['components']))
    print('consumer composition receipt and composed-envelope pinned-tree required/const checks: PASS')

    entries = lock['components']
    expected_files = {'bundle.lock.json', lock['composed']['path'], lock['composed']['receipt']}
    for e in entries:
        expected_files.update((e['path'], e['receipt']))
    actual_files = {str(p.relative_to(BUNDLE)) for p in BUNDLE.rglob('*') if p.is_file()}
    require(actual_files == expected_files, f'inventory mismatch: missing={sorted(expected_files-actual_files)} extra={sorted(actual_files-expected_files)}')
    require(len(entries) == 24 and len(expected_files) == 51, 'unexpected inventory cardinality')
    print('inventory: PASS 24 projections + 24 source receipts + 1 composition + 1 composition receipt + 1 lock = 51 files')

    authority = CanonicalAuthority(ROOT, REV, repository='Quantum-L9/.github')
    projection_profile = authority.resolve_profile(binding['input']['authority']['projection_profile_ref'])
    composition_profile = authority.resolve_profile(binding['input']['authority']['composition_profile_ref'])
    projection_governing = engine._governing(authority, engine.PROJECTION_ENGINE_REF, engine.PROJECTION_SCHEMA_REF, projection_profile.catalog)
    composition_governing = engine._governing(authority, engine.COMPOSITION_ENGINE_REF, engine.COMPOSED_SCHEMA_REF, composition_profile.catalog)
    receipt_schema = authority.artifact_schema(engine.RECEIPT_SCHEMA_REF).document
    projection_schema = authority.artifact_schema(engine.PROJECTION_SCHEMA_REF).document
    composed_schema = authority.artifact_schema(engine.COMPOSED_SCHEMA_REF).document
    projection_payload_schema = authority.artifact_schema('l9.schema/architecture-intelligence-projection@1')
    composed_payload_schema = authority.artifact_schema('l9.schema/architecture-intelligence-composition@1')

    print('producer receipt validator module:', validate_receipt_document.__module__)
    print('producer identity digest module:', digest.__module__)
    for entry in entries:
        cls = entry['source_class']
        receipt = load(BUNDLE / entry['receipt'])
        artifact = load(BUNDLE / entry['path'])
        source = authority.resolve_source(projection_profile.catalog, cls)
        subject = projection_profile.ref + '#' + source.ref
        validate_receipt_document(receipt, expected_subject_ref=subject)
        identity_body = {k: v for k, v in receipt.items() if k != 'receipt_digest'}
        identity_body['receipt_identity'] = 'pending'
        expected_identity = 'l9.receipt-instance/' + digest(identity_body).split(':', 1)[1]
        require(receipt['receipt_identity'] == expected_identity, f'{cls}: receipt identity mismatch')
        require(receipt['governing_coordinates'] == projection_governing, f'{cls}: exact governing coordinates mismatch')
        require(receipt['inputs'] == [{'ref': source.ref, 'digest': source.document.digest, 'revision': REV, 'path': source.document.path}], f'{cls}: receipt source input coordinate mismatch')
        criteria = receipt['verification_basis']['criteria']
        require(criteria['envelope_schema']['schema'] == authority.artifact_schema(engine.PROJECTION_SCHEMA_REF).coordinate(), f'{cls}: envelope schema coordinate mismatch')
        require(criteria['payload_schema']['schema_artifact'] == projection_payload_schema.coordinate(), f'{cls}: payload schema coordinate mismatch')
        validate_shape(receipt, receipt_schema, cls + ' receipt')
        validate_shape(artifact, projection_schema, cls + ' projection envelope')
        validate_shape(artifact['payload'], projection_payload_schema.document, cls + ' projection payload')
        print(f"PASS {cls}: subject={subject} identity={receipt['receipt_identity']} digest={receipt['receipt_digest']} governing=exact input=exact schemas=pass")

    composed = bundle_result['composed']
    receipt = load(BUNDLE / lock['composed']['receipt'])
    subject = composition_profile.ref + '#' + projection_profile.ref
    validate_receipt_document(receipt, expected_subject_ref=subject)
    identity_body = {k: v for k, v in receipt.items() if k != 'receipt_digest'}
    identity_body['receipt_identity'] = 'pending'
    expected_identity = 'l9.receipt-instance/' + digest(identity_body).split(':', 1)[1]
    require(receipt['receipt_identity'] == expected_identity, 'composed: receipt identity mismatch')
    require(receipt['governing_coordinates'] == composition_governing, 'composed: exact governing coordinates mismatch')
    require(receipt['inputs'] == [{'ref': c['projection_ref'], 'digest': c['projection_digest']} for c in composed['components']], 'composed: inputs mismatch')
    criteria = receipt['verification_basis']['criteria']
    require(criteria['envelope_schema']['schema'] == authority.artifact_schema(engine.COMPOSED_SCHEMA_REF).coordinate(), 'composed: envelope schema coordinate mismatch')
    require(criteria['payload_schema']['schema_artifact'] == composed_payload_schema.coordinate(), 'composed: payload schema coordinate mismatch')
    validate_shape(receipt, receipt_schema, 'composition receipt')
    validate_shape(composed, composed_schema, 'composition envelope')
    validate_shape(composed['payload'], composed_payload_schema.document, 'composition payload')
    print(f"PASS composed: subject={subject} identity={receipt['receipt_identity']} digest={receipt['receipt_digest']} governing=exact input=exact schemas=pass")
    print('TOTAL: 25/25 receipt validator, recomputed identities, exact governing coordinates, and producer schema-interpreter checks PASS')
    print('LIMIT: no trusted production attestation, admission decision, deterministic replay, or selector re-execution')


if __name__ == '__main__':
    try:
        main()
    except gar.Outcome as exc:
        print('CONSUMER OUTCOME:', exc.status, exc.reason, json.dumps(exc.detail, sort_keys=True), file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        import traceback
        traceback.print_exc()
        sys.exit(1)
