#!/usr/bin/env python3
"""Run isolated negative controls on the pre-existing baseline; no network or repository writes.

Run: PYTHONDONTWRITEBYTECODE=1 python3 /home/ubuntu/l9-projection-campaign/baseline-negative-controls/run_controls.py
Each invocation makes a new run-* directory under this script's directory; nothing is deleted.
The pinned consumer verifier and replay driver are executed as subprocesses, never replaced.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

QA = Path('/tmp/l9-projection-qa.nBKv8FWo')
SCRATCH = Path('/home/ubuntu/l9-projection-campaign/baseline-negative-controls')
BASELINE = QA / 'baseline'
CONSUMER = QA / 'consumer'
COMPILER_REPO = QA / 'compiler'
AUTHORITY = Path('/home/ubuntu/l9-projection-campaign/verify-baseline-authority')
PYTHON = QA / 'venv/bin/python'
COMPILER = QA / 'venv/bin/l9-semantic-compiler'
VERIFIER = CONSUMER / 'skills/l9-global-architect/scripts/verify_architecture_intelligence.py'
DRIVER = CONSUMER / 'tools/authority/produce_projection_bundle.py'
PIN_BASE = '020a94bea86e7c5c5e4107da7014ec259508f397'
PIN_COMPILER = '943db9a462d35ba66771a700ece77c746295f591'
PIN_CONSUMER = '8e4b352a0849ad6b04cda61ea9aa41f6fb1523a2'
CANDIDATE_SHA = '432788798e06dfedd1f0089a7e2dd4e162d8032f'
PROFILE = 'l9.projection/architecture-intelligence@1'
PROJECTION = 'projections/vocabulary.projection.json'
SOURCE_RECEIPT = 'receipts/vocabulary.receipt.json'
COMPOSITION_RECEIPT = 'receipts/composed.receipt.json'


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def tree(root: Path) -> dict[str, str]:
    paths = list(root.rglob('*'))
    if any(p.is_symlink() for p in paths):
        raise RuntimeError(f'symlink found under bundle: {root}')
    return {str(p.relative_to(root)): digest(p.read_bytes()) for p in sorted(paths) if p.is_file()}


def git(root: Path, *args: str) -> str:
    p = subprocess.run(['git', '-C', str(root), *args], env=ENV, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    return p.stdout.strip()


def write_json(path: Path, doc: object) -> None:
    path.write_text(json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')


def replace_once(path: Path, old: bytes, new: bytes) -> None:
    data = path.read_bytes()
    if data.count(old) != 1:
        raise RuntimeError(f'expected exactly one mutation match in {path}')
    path.write_bytes(data.replace(old, new, 1))


def compiler_provenance() -> dict:
    source = COMPILER_REPO / 'src/l9_semantic_compiler'
    out = subprocess.run([str(PYTHON), '-c', 'import l9_semantic_compiler; print(l9_semantic_compiler.__file__)'],
                         env=ENV, text=True, capture_output=True, check=True)
    installed = Path(out.stdout.strip()).parent
    tracked = git(COMPILER_REPO, 'ls-tree', '-r', PIN_COMPILER, '--', 'src/l9_semantic_compiler').splitlines()
    pinned = {}
    for line in tracked:
        meta, fullpath = line.split('\t', 1)
        mode, typ, oid = meta.split()
        if typ != 'blob' or mode != '100644':
            raise RuntimeError(f'unexpected compiler tree entry: {line}')
        pinned[str(Path(fullpath).relative_to('src/l9_semantic_compiler'))] = oid
    src_files = {str(p.relative_to(source)): p for p in source.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    inst_files = {str(p.relative_to(installed)): p for p in installed.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    if set(pinned) != set(src_files) or set(pinned) != set(inst_files):
        raise RuntimeError('installed/source compiler file inventory differs from the pinned git tree')
    for name, oid in pinned.items():
        b = src_files[name].read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        if blob != oid or inst_files[name].read_bytes() != b:
            raise RuntimeError(f'compiler does not match pinned source: {name}')
    return {'installed_package': str(installed), 'tracked_files_checked': len(pinned),
            'installed_matches_pinned_source': True, 'compiler_executable_sha256': digest(COMPILER.read_bytes())}


def run_command(command: list[str], timeout: int = 300) -> dict:
    started = time.monotonic()
    try:
        completed = subprocess.run(command, cwd=str(RUN), env=ENV, capture_output=True,
                                   text=True, timeout=timeout, check=False)
        return {'command': command, 'shell_command': shlex.join(command), 'exit_code': completed.returncode,
                'stdout': completed.stdout, 'stderr': completed.stderr,
                'duration_seconds': round(time.monotonic() - started, 3)}
    except subprocess.TimeoutExpired as exc:
        return {'command': command, 'shell_command': shlex.join(command), 'exit_code': None,
                'stdout': (exc.stdout or b'').decode() if isinstance(exc.stdout, bytes) else (exc.stdout or ''),
                'stderr': (exc.stderr or b'').decode() if isinstance(exc.stderr, bytes) else (exc.stderr or ''),
                'timeout_seconds': timeout, 'duration_seconds': round(time.monotonic() - started, 3)}


def verify_command(bundle: Path, revision: str = PIN_BASE) -> list[str]:
    return [str(PYTHON), str(VERIFIER), '--mode', 'candidate', '--bundle', str(bundle),
            '--authority-root', str(AUTHORITY), '--expect-revision', revision]


def replay_command(bundle: Path) -> list[str]:
    return [str(PYTHON), str(DRIVER), '--profile', PROFILE, '--authority-root', str(AUTHORITY),
            '--authority-revision', PIN_BASE, '--compiler-revision', PIN_COMPILER,
            '--compiler', str(COMPILER), '--output', str(bundle), '--check']


def case(name: str, mutation: str, expected: dict, kind: str, revision: str = PIN_BASE) -> dict:
    bundle = RUN / 'copies' / name
    shutil.copytree(BASELINE, bundle)
    before = tree(bundle)
    if before != BASELINE_HASHES:
        raise RuntimeError(f'copy differs from original prior to mutation: {name}')
    target = None
    if mutation == 'missing_component':
        target = PROJECTION
        (bundle / target).unlink()
    elif mutation == 'payload':
        target = PROJECTION
        replace_once(bundle / target, b'          "authority",\n', b'          "authority_negative_control",\n')
    elif mutation in ('source_receipt', 'composition_receipt'):
        target = SOURCE_RECEIPT if mutation == 'source_receipt' else COMPOSITION_RECEIPT
        replace_once(bundle / target,
                     b'"claim": "declared semantic compilation executed against exact inputs and profile"',
                     b'"claim": "declared semantic compilation executed against exact inputs and profile [negative control]"')
    elif mutation != 'none':
        raise RuntimeError(f'unknown mutation: {mutation}')
    after = tree(bundle)
    changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
    if changed != ([] if target is None else [target]):
        raise RuntimeError(f'wrong mutation inventory for {name}: {changed}')
    command = verify_command(bundle, revision) if kind == 'verifier' else replay_command(bundle)
    result = run_command(command)
    parsed = None
    parse_error = None
    if kind == 'verifier':
        try:
            parsed = json.loads(result['stdout'])
        except (ValueError, TypeError) as exc:
            parse_error = str(exc)
        observed = {'exit_code': result['exit_code'],
                    'status': parsed.get('status') if isinstance(parsed, dict) else None,
                    'reason': parsed.get('reason') if isinstance(parsed, dict) else None,
                    'detail': parsed.get('detail') if isinstance(parsed, dict) else None}
        pass_ = bool(parsed is not None and all(observed.get(k) == v for k, v in expected.items() if k != 'detail_contains'))
        for key, val in expected.get('detail_contains', {}).items():
            pass_ = pass_ and isinstance(observed['detail'], dict) and observed['detail'].get(key) == val
        if name == 'positive_verifier':
            slot = parsed.get('architecture_intelligence', {}) if isinstance(parsed, dict) else {}
            pass_ = pass_ and slot.get('authoritative') is False and slot.get('currentness', {}).get('checked_against') == PIN_BASE
        result['verifier_output'] = parsed
        result['parse_error'] = parse_error
    else:
        observed = {'exit_code': result['exit_code'], 'stdout': result['stdout'], 'stderr': result['stderr']}
        pass_ = (result['exit_code'] == expected['exit_code'] and
                 result['stdout'] == expected['stdout'] and result['stderr'] == expected['stderr'])
    # --check must not rewrite the copy and none of the verifications should do so either.
    output_hashes = tree(bundle)
    untouched_by_tool = output_hashes == after
    pass_ = bool(pass_ and untouched_by_tool)
    record = {'name': name, 'tool': kind, 'bundle_copy': str(bundle), 'mutation': mutation,
              'mutated_relative_paths': changed, 'mutation_file_hashes': {
                  p: {'before_sha256': before.get(p), 'after_sha256': after.get(p)} for p in changed},
              'expected': expected, 'observed': observed, 'tool_left_copy_unchanged': untouched_by_tool,
              'pass': pass_, 'execution': result}
    return record


def main() -> int:
    global RUN, ENV, BASELINE_HASHES
    if Path(__file__).resolve().parent != SCRATCH.resolve() or SCRATCH.is_symlink():
        raise RuntimeError('script must be located inside the designated non-symlink scratch directory')
    RUN = Path(tempfile.mkdtemp(prefix='run-', dir=SCRATCH))
    (RUN / 'copies').mkdir()
    (RUN / 'tmp').mkdir()
    ENV = os.environ.copy()
    ENV.update({'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': '', 'TMPDIR': str(RUN / 'tmp'),
                'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_REPLACE_OBJECTS': '1', 'GIT_NO_LAZY_FETCH': '1',
                'GIT_TERMINAL_PROMPT': '0', 'GIT_ALLOW_PROTOCOL': 'file', 'LC_ALL': 'C'})
    report = {'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'run_directory': str(RUN), 'baseline': str(BASELINE), 'authority_root': str(AUTHORITY),
              'pins': {'authority': PIN_BASE, 'compiler': PIN_COMPILER, 'consumer': PIN_CONSUMER,
                       'wrong_expected_candidate_sha': CANDIDATE_SHA},
              'profile': PROFILE, 'environment_overrides': {k: ENV[k] for k in
                ('PYTHONDONTWRITEBYTECODE', 'PYTHONPATH', 'TMPDIR', 'GIT_OPTIONAL_LOCKS',
                 'GIT_NO_REPLACE_OBJECTS', 'GIT_NO_LAZY_FETCH', 'GIT_TERMINAL_PROMPT', 'GIT_ALLOW_PROTOCOL', 'LC_ALL')},
              'limitations': ['Baseline architecture-intelligence profile only; not a candidate-profile test.',
                'Consumer candidate mode is non-authoritative and is not admission or protected-main replay.',
                'Simple uncoordinated single-file tampering; no adversarial recomputation of all dependent digests.',
                'Compiler producer revision in the lock is caller-asserted; local package bytes checked against pinned checkout.',
                'No network, commits, pushes, edits to original QA/baseline, working repositories, candidate fixture, release records, or producer/consumer code.'],
              'cases': []}
    log_path = RUN / 'controls.log'
    try:
        for root, expected in ((AUTHORITY, PIN_BASE), (COMPILER_REPO, PIN_COMPILER), (CONSUMER, PIN_CONSUMER)):
            actual = git(root, 'rev-parse', 'HEAD')
            if actual != expected:
                raise RuntimeError(f'{root} HEAD {actual}, expected {expected}')
        if git(QA / 'candidate', 'rev-parse', 'HEAD') != CANDIDATE_SHA:
            raise RuntimeError('candidate SHA no longer matches the expected local candidate')
        selected = ['skills/l9-global-architect/scripts/verify_architecture_intelligence.py',
                    'skills/l9-coding-agent/scripts/verify_canonical_binding.py',
                    'skills/l9-global-architect/integrations/ARCHITECTURE_INTELLIGENCE_BINDING.yaml',
                    'tools/authority/produce_projection_bundle.py']
        entrypoints = {}
        for path in selected:
            pinned_oid = git(CONSUMER, 'rev-parse', f'{PIN_CONSUMER}:{path}')
            actual_oid = git(CONSUMER, 'hash-object', path)
            if actual_oid != pinned_oid:
                raise RuntimeError(f'consumer file differs from pinned blob: {path}')
            entrypoints[path] = {'git_blob': pinned_oid, 'sha256': digest((CONSUMER / path).read_bytes())}
        report['consumer_pinned_entrypoints'] = entrypoints
        report['compiler_provenance'] = compiler_provenance()
        BASELINE_HASHES = tree(BASELINE)
        if len(BASELINE_HASHES) != 51:
            raise RuntimeError(f'baseline inventory size is {len(BASELINE_HASHES)}, expected 51')
        lock = json.loads((BASELINE / 'bundle.lock.json').read_text())
        if lock['authority']['revision'] != PIN_BASE or lock['producer']['revision'] != PIN_COMPILER:
            raise RuntimeError('baseline lock pins do not match expected authority/compiler')
        report['baseline_file_count'] = len(BASELINE_HASHES)
        report['baseline_file_sha256_before'] = BASELINE_HASHES
        tests = [
            ('positive_verifier', 'none', {'exit_code': 5, 'status': 'BUNDLE_VERIFIED', 'reason': 'CANDIDATE_MODE'}, 'verifier', PIN_BASE),
            ('missing_component', 'missing_component', {'exit_code': 3, 'status': 'BLOCKED', 'reason': 'ARTIFACT_UNREADABLE'}, 'verifier', PIN_BASE),
            ('tampered_projection_payload', 'payload', {'exit_code': 1, 'status': 'REJECTED', 'reason': 'BUNDLE_BYTES_MISMATCH', 'detail_contains': {'path': PROJECTION}}, 'verifier', PIN_BASE),
            ('tampered_source_receipt', 'source_receipt', {'exit_code': 1, 'status': 'REJECTED', 'reason': 'RECEIPT_DIGEST_MISMATCH', 'detail_contains': {'source_class': 'vocabulary'}}, 'verifier', PIN_BASE),
            ('tampered_composition_receipt', 'composition_receipt', {'exit_code': 1, 'status': 'REJECTED', 'reason': 'RECEIPT_DIGEST_MISMATCH', 'detail_contains': {'source_class': 'composed'}}, 'verifier', PIN_BASE),
            ('wrong_expected_authority_revision', 'none', {'exit_code': 4, 'status': 'STALE', 'reason': 'AUTHORITY_REVISION_MISMATCH', 'detail_contains': {'bundle': PIN_BASE, 'expected': CANDIDATE_SHA}}, 'verifier', CANDIDATE_SHA),
            ('positive_replay_check', 'none', {'exit_code': 0, 'stdout': f'projection bundle {PROFILE} is current at {PIN_BASE}\n', 'stderr': ''}, 'replay_check', PIN_BASE),
            ('tampered_replay_check', 'payload', {'exit_code': 1, 'stdout': '', 'stderr': f'stale projection bundle {PROFILE}:\n  {PROJECTION}\n'}, 'replay_check', PIN_BASE),
        ]
        with log_path.open('w', encoding='utf-8') as log:
            print(f'RUN_DIRECTORY={RUN}\nAUTHORITY_ROOT={AUTHORITY}\nPYTHONDONTWRITEBYTECODE=1\n', file=log, flush=True)
            for spec in tests:
                record = case(*spec)
                report['cases'].append(record)
                ex = record['execution']
                print(f"=== {record['name']} ===\ncommand: {ex['shell_command']}\nexpected: {json.dumps(record['expected'], sort_keys=True)}\nobserved: {json.dumps(record['observed'], sort_keys=True)}\nexit: {ex['exit_code']}\nverdict: {'PASS' if record['pass'] else 'FAIL'}\n--- stdout ---\n{ex['stdout']}--- stderr ---\n{ex['stderr']}--- end ---\n", file=log, flush=True)
                print(f"{record['name']}: {'PASS' if record['pass'] else 'FAIL'} (exit {ex['exit_code']})", flush=True)
        after = tree(BASELINE)
        report['baseline_file_sha256_after'] = after
        report['baseline_unchanged'] = after == BASELINE_HASHES
        report['overall_pass'] = report['baseline_unchanged'] and len(report['cases']) == len(tests) and all(c['pass'] for c in report['cases'])
        with log_path.open('a', encoding='utf-8') as log:
            print(f"baseline unchanged: {report['baseline_unchanged']}\noverall: {'PASS' if report['overall_pass'] else 'FAIL'}", file=log)
    except Exception as exc:
        report['overall_pass'] = False
        report['harness_error'] = f'{type(exc).__name__}: {exc}'
        with log_path.open('a', encoding='utf-8') as log:
            print(f'HARNESS ERROR: {report["harness_error"]}', file=log)
        print(f'HARNESS ERROR: {report["harness_error"]}', file=sys.stderr)
    report['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    report_path = RUN / 'report.json'
    write_json(report_path, report)
    print(f'REPORT={report_path}\nLOG={log_path}\nOVERALL={"PASS" if report["overall_pass"] else "FAIL"}', flush=True)
    return 0 if report['overall_pass'] else 1


if __name__ == '__main__':
    sys.exit(main())
