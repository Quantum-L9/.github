# Projection qualification evidence

## Governing coordinates

- Baseline authority: `Quantum-L9/.github@020a94bea86e7c5c5e4107da7014ec259508f397`.
- Local-only candidate: `432788798e06dfedd1f0089a7e2dd4e162d8032f`, a scratch child of the baseline, not a published or admitted revision.
- Real producer: `Quantum-L9/l9-semantic-compiler-engine@943db9a462d35ba66771a700ece77c746295f591`.
- Consumer driver and verifier: `Quantum-L9/Cursor-Governance@8e4b352a0849ad6b04cda61ea9aa41f6fb1523a2`.

## 1. Baseline receipt verification — PASS at the named pin

The real GAR consumer verifier returned `BUNDLE_VERIFIED` in candidate mode, its documented exit code 5. Its candidate mode is non-authoritative and does not attest production. Supplementary calls to the real shared consumer verifier checked the lock, all 24 source projections and source receipts, and the composition receipt against a clean, hash-checked pinned authority checkout. The real producer's canonical schema interpreter was also applied to the envelopes, payloads and receipts. The 25 receipt identities were separately recomputed using the producer's canonical digest function and the governing contract's identity convention. All checks passed. The verifier does not independently prove producer execution from receipts alone.

## 2. Independent deterministic baseline replay — PASS

The unchanged consumer driver was actually rerun with `--check` at the baseline authority and producer pins. It regenerated and compared all bundle files and exited 0: `projection bundle l9.projection/architecture-intelligence@1 is current at 020a94bea86e7c5c5e4107da7014ec259508f397`. A separate negative control altered a copy of the baseline projection; the same `--check` rejected it with exit 1. This is a local replay, not the protected-main trusted workflow or a published attestation.

## 3. Ten-profile candidate qualification — BLOCKED

Each of the ten candidate profiles was projected twice and actually composed twice with the real pinned producer. For every profile, projection and composition returned `unknown`, exit 3: output payload schemas were unresolved, with unresolved component criteria propagated to composition. Across the two executions, all projection artifacts, source receipts, composed artifacts and composition receipts were byte-identical for 10/10 profiles. These are diagnostic producer outputs, not accepted consumer bundles. The unchanged consumer driver requires PASS and cannot create the requested qualifying bundles under these conditions; therefore bundle-to-bundle comparison and candidate consumer replay remain unproven.

The real producer's negative-control matrix reported 100/100 expected fail-closed outcomes across ten profiles: missing source pin, wrong source pin, wrong profile pin, changed payload with and without digest recomputation, simulated stale source digest, missing or duplicate composition component, wrong composition-profile pin, and changed receipt without digest recomputation. The stale-source test used a forged digest, not an actual intervening revision; receipt testing used the producer helper, not a candidate consumer. One source and one receipt per profile were targeted.

The baseline consumer/replay controls additionally passed two positive controls and six negative controls for missing component, modified projection, modified source receipt, modified composition receipt, wrong expected authority revision, and modified-bundle replay. A missing file was BLOCKED and a wrong revision STALE, rather than REJECTED.

## Evidence in the archive

- `baseline/`: baseline bundle, consumer verifier JSON, pinned-coordinate receipt checks and log, actual `--check` log, and baseline negative-control report and harness.
- `candidate/diagnostic/`: real producer requests, outputs, receipts and two-run comparisons for all ten profiles.
- `candidate/negative-controls/`: 100-case producer negative-control results, copies used for tests, and harness.
- `candidate/previous-driver-qualification.log`: unchanged driver's earlier 0/10 qualification result.

Absolute paths in the logs and harnesses refer to the original sandbox; change them before rerunning elsewhere. The existing `v3.27.0` release record was not modified. No candidate was admitted, published or merged.
