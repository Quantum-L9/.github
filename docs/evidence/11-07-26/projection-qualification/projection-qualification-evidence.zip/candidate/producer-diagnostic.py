#!/usr/bin/env python3
"""Run two genuine pinned-producer diagnostics per candidate profile.

This does not call the Cursor-Governance produce/assemble driver and does not make
consumer bundles. It only imports its unchanged composition_pin/source_classes
helpers. Unknown outputs and typed failures are recorded, never admitted as passes.
Run with the QA venv Python; --output must be a new directory under the campaign.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

import yaml

CAMPAIGN = Path('/home/ubuntu/l9-projection-campaign')
REVISION = '432788798e06dfedd1f0089a7e2dd4e162d8032f'
COMPILER_REVISION = '943db9a462d35ba66771a700ece77c746295f591'
CONSUMER_REVISION = '8e4b352a0849ad6b04cda61ea9aa41f6fb1523a2'
REPOSITORY = 'Quantum-L9/.github'
NAMES = [
    'authority-resolution', 'evidence-assessment', 'semantic-change-context',
    'architecture-break-test', 'globalization-assessment', 'work-state-continuity',
    'strategic-planning-context', 'strategic-metacognition', 'identity-assurance',
    'hard-constraint-context',
]
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
sys.dont_write_bytecode = True


def run_checked(command):
    return subprocess.run(command, check=True, text=True, capture_output=True, env=ENV).stdout.strip()


def git_head(root):
    return run_checked(['git', '-C', str(root), 'rev-parse', 'HEAD'])


def git_status(root):
    return run_checked(['git', '-C', str(root), 'status', '--porcelain', '--untracked-files=all'])


def file_digest(path):
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


def dump_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, default=str) + '\n', encoding='utf-8')


def command_capture(label, argv, directory):
    """No check=True: native typed failure/unknown exit codes are evidence, not exceptions."""
    record = {'attempted': True, 'command': [str(x) for x in argv]}
    try:
        proc = subprocess.run(record['command'], cwd=directory, env=ENV,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              check=False, timeout=180)
        out, err, record['returncode'] = proc.stdout, proc.stderr, proc.returncode
    except subprocess.TimeoutExpired as exc:
        out, err = exc.stdout or b'', exc.stderr or b''
        record.update(returncode=None, error=f'timed out after {exc.timeout}s')
    except Exception as exc:
        out, err = b'', b''
        record.update(returncode=None, error=f'{type(exc).__name__}: {exc}', traceback=traceback.format_exc())
    if isinstance(out, str):
        out = out.encode('utf-8')
    if isinstance(err, str):
        err = err.encode('utf-8')
    (directory / f'{label}.stdout.log').write_bytes(out)
    (directory / f'{label}.stderr.log').write_bytes(err)
    record['stdout'] = out.decode('utf-8', errors='replace')
    record['stderr'] = err.decode('utf-8', errors='replace')
    try:
        record['parsed_stdout'] = yaml.safe_load(record['stdout'])
    except yaml.YAMLError as exc:
        record['parse_error'] = f'{type(exc).__name__}: {exc}'
        record['parsed_stdout'] = None
    dump_json(directory / f'{label}.command.json', record)
    return record


def emitted_files(root, category):
    if not root.is_dir():
        return {}
    files = {}
    for p in sorted(root.rglob('*')):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        receipt = len(rel.parts) > 0 and rel.parts[0] == 'receipts'
        if (category == 'receipts') == receipt:
            files[str(rel)] = p
    return files


def compare_trees(first, second, category):
    """Compare exact bytes and relative names; never compare CLI logs/requests."""
    a, b = emitted_files(first, category), emitted_files(second, category)
    if not a and not b:
        return {'state': 'not_produced', 'equal': None, 'run1_files': 0, 'run2_files': 0, 'differences': []}
    differences = []
    for name in sorted(set(a) | set(b)):
        if name not in a:
            differences.append({'path': name, 'difference': 'missing_in_run1', 'run2_sha256': file_digest(b[name])})
        elif name not in b:
            differences.append({'path': name, 'difference': 'missing_in_run2', 'run1_sha256': file_digest(a[name])})
        elif a[name].read_bytes() != b[name].read_bytes():
            differences.append({'path': name, 'difference': 'bytes_differ', 'run1_sha256': file_digest(a[name]), 'run2_sha256': file_digest(b[name])})
    return {'state': 'compared', 'equal': not differences, 'run1_files': len(a), 'run2_files': len(b), 'differences': differences}


def producer_result(record):
    if not record:
        return None
    obj = record.get('parsed_stdout')
    if isinstance(obj, dict):
        return obj.get('result')
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=CAMPAIGN / 'candidate-diagnostic',
                        help='new scratch directory directly under the campaign')
    args = parser.parse_args()
    out = args.output.absolute()
    if out.parent.resolve() != CAMPAIGN.resolve() or out.name in {'repo', 'compiler-inspection', 'verify-baseline-authority'}:
        raise SystemExit('Refusing output outside a new direct child of the campaign directory')
    if out.exists() or out.is_symlink():
        raise SystemExit(f'Refusing existing output path: {out}')
    qa = Path((CAMPAIGN / 'qa-root.txt').read_text(encoding='utf-8').strip()).resolve()
    authority, compiler_root, consumer = qa / 'candidate', qa / 'compiler', qa / 'consumer'
    binary = qa / 'venv/bin/l9-semantic-compiler'
    driver_path = consumer / 'tools/authority/produce_projection_bundle.py'
    verification = (CAMPAIGN / 'verify-baseline-checks.log').read_text(encoding='utf-8')
    replay = (CAMPAIGN / 'baseline-independent-replay.log').read_text(encoding='utf-8')
    for marker in ('consumer pinned-tree verification: PASS', 'inventory: PASS', 'TOTAL: 25/25'):
        if marker not in verification:
            raise SystemExit(f'Baseline verification prerequisite missing: {marker}')
    if 'Actual --check exit code: 0' not in replay or 'is current at 020a94bea86e7c5c5e4107da7014ec259508f397' not in replay:
        raise SystemExit('Independent baseline --check prerequisite missing')
    if Path(sys.executable).resolve() != (qa / 'venv/bin/python').resolve():
        raise SystemExit(f'Use QA venv Python: {qa / "venv/bin/python"}')
    if not binary.is_file() or not driver_path.is_file():
        raise SystemExit('Pinned producer CLI or unchanged driver helper is missing')
    roots = {'candidate': (authority, REVISION), 'compiler': (compiler_root, COMPILER_REVISION), 'consumer': (consumer, CONSUMER_REVISION)}
    preflight = {}
    for label, (root, required) in roots.items():
        head, status = git_head(root), git_status(root)
        preflight[label] = {'root': str(root), 'head': head, 'status_porcelain': status}
        if head != required or status:
            raise SystemExit(f'{label} checkout is not clean at required revision: {head}, {status}')
    spec = importlib.util.spec_from_file_location('existing_cursor_governance_driver', driver_path)
    if spec is None or spec.loader is None:
        raise SystemExit('Cannot load unchanged driver helpers')
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    out.mkdir()
    progress_path = out / 'progress.log'
    def progress(msg):
        print(msg, flush=True)
        with progress_path.open('a', encoding='utf-8') as f:
            f.write(msg + '\n')

    aggregate = {
        'description': 'Real pinned-producer diagnostics only; these raw trees are not consumer bundles.',
        'qualification': 'Unknown results or typed errors are non-qualification; no consumer-bundle qualification was attempted.',
        'candidate_revision': REVISION, 'producer_revision': COMPILER_REVISION,
        'consumer_driver_revision': CONSUMER_REVISION, 'authority_repository': REPOSITORY,
        'qa_root': str(qa), 'authority_root': str(authority), 'producer_cli': str(binary),
        'producer_cli_sha256': file_digest(binary), 'unchanged_driver': str(driver_path),
        'driver_sha256': file_digest(driver_path), 'composition_digest_helper': 'Cursor-Governance driver composition_pin',
        'baseline_verification_log': str(CAMPAIGN / 'verify-baseline-checks.log'),
        'baseline_check_log': str(CAMPAIGN / 'baseline-independent-replay.log'),
        'preflight': preflight, 'profiles': {},
    }
    for name in NAMES:
        profile, composition = f'l9.projection/{name}@1', f'l9.compose/{name}@1'
        prof = {'profile': profile, 'composition_profile': composition, 'runs': [], 'diagnostic_errors': []}
        aggregate['profiles'][name] = prof
        try:
            # Read exact catalog coordinates from commit objects through the existing driver helper.
            pin = driver.composition_pin(authority, REVISION, composition)
            classes = driver.source_classes(authority, REVISION, profile)
            prof['composition_pin'] = pin
            prof['declared_sources'] = [{'source_class': c, 'source_ref': r} for c, r in classes]
        except Exception as exc:
            pin = None
            prof['diagnostic_errors'].append({'stage': 'driver_helpers', 'error': f'{type(exc).__name__}: {exc}', 'traceback': traceback.format_exc()})
        for n in (1, 2):
            run = out / f'run-{n}' / name
            run.mkdir(parents=True)
            rec = {'run': n, 'directory': str(run), 'coordinates': None, 'project': None, 'compose': None, 'errors': []}
            prof['runs'].append(rec)
            try:
                coord = command_capture('coordinates', [binary, 'projection-coordinates', '--authority-root', authority,
                    '--revision', REVISION, '--repository', REPOSITORY, '--profile', profile], run)
                rec['coordinates'] = coord
                coordinate_doc = coord.get('parsed_stdout')
                if coord['returncode'] != 0 or not isinstance(coordinate_doc, dict) or not all(k in coordinate_doc for k in ('projection_profile', 'sources')):
                    rec['errors'].append('Coordinates unavailable; a valid projection request cannot be constructed.')
                else:
                    auth = {'repository': REPOSITORY, 'root': str(authority), 'revision': REVISION}
                    project_out = run / 'projection-output'
                    request = {'schema': 'l9.semantic-projection-request/v1', 'authority': auth,
                               'projection_profile': coordinate_doc['projection_profile'], 'sources': coordinate_doc['sources'],
                               'output_root': str(project_out)}
                    project_request = run / 'project.request.yaml'
                    project_request.write_text(yaml.safe_dump(request), encoding='utf-8')
                    proj = command_capture('project', [binary, 'project', project_request], run)
                    rec['project'] = proj
                    doc = proj.get('parsed_stdout')
                    artifacts = doc.get('artifacts', []) if isinstance(doc, dict) else []
                    components = []
                    for item in artifacts:
                        if isinstance(item, dict) and isinstance(item.get('path'), str):
                            artifact_path = Path(item['path'])
                            if artifact_path.is_file() and artifact_path.resolve().is_relative_to(project_out.resolve()):
                                components.append(str(artifact_path))
                            else:
                                rec['errors'].append(f'Producer-listed artifact missing or outside projection output: {artifact_path}')
                    rec['emitted_component_paths'] = components
                    # Continue on project rc=3/result=unknown using exactly producer-emitted per-source paths.
                    if pin is not None and components:
                        compose_request = run / 'compose.request.yaml'
                        compose_request.write_text(yaml.safe_dump({'schema': 'l9.semantic-composition-request/v1',
                            'authority': auth, 'composition_profile': pin, 'components': components,
                            'output_root': str(run / 'composition-output')}), encoding='utf-8')
                        rec['compose'] = command_capture('compose', [binary, 'compose', compose_request], run)
                    else:
                        rec['errors'].append('Compose not attempted: no usable producer-emitted components or no exact composition pin; no negative request was fabricated.')
            except Exception as exc:
                rec['errors'].append(f'{type(exc).__name__}: {exc}\n{traceback.format_exc()}')
            dump_json(run / 'run-result.json', rec)
            progress(f'{name} run={n} coordinates_rc={rec["coordinates"]["returncode"] if rec["coordinates"] else None} '
                     f'project_rc={rec["project"]["returncode"] if rec["project"] else None} project_result={producer_result(rec["project"])} '
                     f'components={len(rec.get("emitted_component_paths", []))} '
                     f'compose_attempted={rec["compose"] is not None} compose_rc={rec["compose"]["returncode"] if rec["compose"] else None} '
                     f'compose_result={producer_result(rec["compose"])}')
        r1, r2 = [Path(r['directory']) for r in prof['runs']]
        prof['determinism'] = {
            'projection_artifacts': compare_trees(r1 / 'projection-output', r2 / 'projection-output', 'artifacts'),
            'projection_receipts': compare_trees(r1 / 'projection-output', r2 / 'projection-output', 'receipts'),
            'composition_artifacts': compare_trees(r1 / 'composition-output', r2 / 'composition-output', 'artifacts'),
            'composition_receipts': compare_trees(r1 / 'composition-output', r2 / 'composition-output', 'receipts'),
        }
        dump_json(out / f'{name}.result.json', prof)
        dump_json(out / 'results.json', aggregate)
    runs = [r for p in aggregate['profiles'].values() for r in p['runs']]
    def counts(command):
        records = [r[command] for r in runs if r[command] is not None]
        return {'attempted': len(records), 'not_attempted': len(runs) - len(records),
                'return_codes': {str(k): sum(x['returncode'] == k for x in records) for k in sorted({x['returncode'] for x in records}, key=str)},
                'results': {str(k): sum(producer_result(x) == k for x in records) for k in sorted({producer_result(x) for x in records}, key=str)}}
    det = {}
    for category in ('projection_artifacts', 'projection_receipts', 'composition_artifacts', 'composition_receipts'):
        checks = [p['determinism'][category] for p in aggregate['profiles'].values()]
        det[category] = {'equal': sum(x['equal'] is True for x in checks),
                         'different': sum(x['equal'] is False for x in checks),
                         'not_produced': sum(x['state'] == 'not_produced' for x in checks)}
    aggregates = [item for r in runs for item in ((r.get('project') or {}).get('parsed_stdout') or {}).get('artifacts', []) if isinstance(item, dict)]
    unknown_items = [a for a in aggregates if a.get('result') == 'unknown']
    aggregate['summary'] = {
        'profiles': len(aggregate['profiles']), 'runs': len(runs),
        'coordinates': counts('coordinates'), 'projection': counts('project'), 'composition': counts('compose'),
        'all_actual_compose_attempted': len(runs) == 20 and all(r['compose'] is not None for r in runs),
        'projection_artifacts_total': len(aggregates), 'projection_artifacts_unknown': len(unknown_items),
        'projection_unresolved_criteria': sorted({str(c) for a in unknown_items for c in a.get('unresolved_criteria', [])}),
        'determinism_by_profile': det,
        'harness_run_errors': sum(len(r['errors']) for r in runs),
        'profile_helper_errors': sum(len(p['diagnostic_errors']) for p in aggregate['profiles'].values()),
    }
    aggregate['postflight'] = {label: {'head': git_head(root), 'status_porcelain': git_status(root)}
                               for label, (root, _) in roots.items()}
    dump_json(out / 'results.json', aggregate)
    dump_json(out / 'summary.json', {k: v for k, v in aggregate.items() if k != 'profiles'})
    progress('SUMMARY ' + json.dumps(aggregate['summary'], sort_keys=True))
    progress(f'Full machine-readable results: {out / "results.json"}')
    return 0 if aggregate['summary']['all_actual_compose_attempted'] and not aggregate['summary']['harness_run_errors'] else 1


if __name__ == '__main__':
    sys.exit(main())
