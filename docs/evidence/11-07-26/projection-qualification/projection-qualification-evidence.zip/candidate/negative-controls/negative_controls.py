#!/usr/bin/env python3
"""Candidate-only, producer-API negative diagnostics; not qualification or trusted replay.

Run with QA/venv/bin/python and PYTHONDONTWRITEBYTECODE=1. Every invocation creates a
fresh run-* directory beneath this script. It never writes to any authority or producer repo,
never creates git objects, and only modifies copies of producer-emitted documents.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from l9_semantic_compiler.engine.compiler import (
    CompositionRequest, ProjectionRequest, SemanticCompiler, load_artifact_file,
)
from l9_semantic_compiler.engine.errors import SemanticCompilerError
from l9_semantic_compiler.engine.receipts import validate_receipt_document
from l9_semantic_compiler.engine.registry import CanonicalAuthority
from l9_semantic_compiler.passes.projection import envelope_digest, projection_coordinates
import l9_semantic_compiler

REVISION = '432788798e06dfedd1f0089a7e2dd4e162d8032f'
COMPILER_REVISION = '943db9a462d35ba66771a700ece77c746295f591'
REPOSITORY = 'Quantum-L9/.github'
QA = Path('/tmp/l9-projection-qa.nBKv8FWo')
OUTPUT = Path(__file__).resolve().parent
NAMES = [
    'authority-resolution', 'evidence-assessment', 'semantic-change-context',
    'architecture-break-test', 'globalization-assessment', 'work-state-continuity',
    'strategic-planning-context', 'strategic-metacognition', 'identity-assurance',
    'hard-constraint-context',
]
# A None criterion is intentional: the real error emits no 'criterion' diagnostic.
CASES = {
    '01_missing_source_pin': ('INVALID_REQUEST', None, 'declared/pinned sets differ by exactly one real source pin'),
    '02_wrong_source_pin': ('REVISION_MISMATCH', 'source_digest', 'wrong pin and actual source digest appear in diagnostics'),
    '03_wrong_profile_pin': ('REVISION_MISMATCH', 'profile_digest', 'wrong pin and actual profile digest appear in diagnostics'),
    '04_payload_tamper_no_redigest': ('REVISION_MISMATCH', 'projection_digest', 'copied payload differs while original digest is retained'),
    '05_payload_tamper_redigested': ('SEMANTIC_DIVERGENCE', 'selection_equivalence', 'real envelope digest recomputed; payload differs from canonical selection'),
    '06_forged_stale_source_digest': ('REVISION_MISMATCH', 'source_currentness', 'simulated digest mismatch; real envelope digest recomputed; no intervening revision'),
    '07_missing_component': ('INVALID_REQUEST', 'source_coverage', 'real compose omits one emitted component and names its missing source class'),
    '08_duplicate_component': ('AMBIGUOUS_SEMANTICS', 'duplicate_source', 'real compose receives the same real emitted component twice'),
    '09_wrong_composition_profile_pin': ('REVISION_MISMATCH', 'composition_profile_digest', 'wrong pin and actual composition digest appear in diagnostics'),
    '10_changed_receipt_no_redigest': ('INVALID_REQUEST', None, 'real receipt copy has changed claim, unchanged result and digest; producer validator finds digest mismatch'),
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def dump(path, doc):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=2, sort_keys=True, ensure_ascii=False, default=str) + '\n', encoding='utf-8')


def sha(path):
    return 'sha256:' + hashlib.sha256(Path(path).read_bytes()).hexdigest()


def wrong(d):
    assert d.startswith('sha256:') and len(d) == 71
    return d[:-1] + ('0' if d[-1] != '0' else '1')


def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True, check=True, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}).stdout.strip()


def error_repr(e):
    return {'type': type(e).__name__, 'code': getattr(e, 'code', None),
            'typed_ref': getattr(e, 'typed_ref', None), 'message': str(e),
            'criterion': getattr(e, 'diagnostics', {}).get('criterion'),
            'diagnostics': getattr(e, 'diagnostics', {}),
            'first_divergence': getattr(e, 'first_divergence', None),
            'traceback': traceback.format_exc()}


def assertion_map(**kwargs):
    return {key: bool(value) for key, value in kwargs.items()}


def run_profile(name, run):
    run = Path(run)
    base = run / 'profiles' / name
    base.mkdir(parents=True, exist_ok=False)
    case_dir = base / 'cases'
    case_dir.mkdir()
    profile_ref = f'l9.projection/{name}@1'
    composition_ref = f'l9.compose/{name}@1'
    auth_spec = {'repository': REPOSITORY, 'root': str(QA / 'candidate'), 'revision': REVISION}
    result = {'name': name, 'profile_ref': profile_ref, 'composition_ref': composition_ref,
              'cases': {}, 'setup': {}, 'warnings': []}

    def record_unrun(case, reason):
        code, criterion, requirement = CASES[case]
        item = {'case': case, 'status': 'unrun', 'reason': reason,
                'expected': {'code': code, 'criterion': criterion, 'requirement': requirement},
                'observed': None}
        result['cases'][case] = item
        dump(case_dir / f'{case}.json', item)

    def test(case, invoke, check, context):
        code, criterion, requirement = CASES[case]
        item = {'case': case, 'expected': {'code': code, 'criterion': criterion,
                                         'requirement': requirement}, 'context': context}
        try:
            returned = invoke()
            item.update(status='failed', observed={'type': 'NO_EXCEPTION', 'code': None,
                        'criterion': None, 'returned': repr(returned)}, checks={})
        except SemanticCompilerError as exc:
            observed = error_repr(exc)
            try:
                checks = {'typed_code': exc.code == code,
                          'typed_ref': exc.typed_ref == f'l9.semantic-compiler.error/{code}',
                          'criterion': exc.diagnostics.get('criterion') == criterion}
                checks.update(check(exc))
                item.update(status='passed' if all(checks.values()) else 'failed',
                            observed=observed, checks=checks)
            except Exception as check_error:
                item.update(status='failed', observed=observed,
                            check_error=error_repr(check_error))
        except Exception as exc:
            item.update(status='failed', observed=error_repr(exc), checks={})
        result['cases'][case] = item
        dump(case_dir / f'{case}.json', item)

    try:
        authority = CanonicalAuthority(QA / 'candidate', REVISION, repository=REPOSITORY)
        coordinates = projection_coordinates(authority, profile_ref)
        comp_resolved = authority.resolve_profile(composition_ref)
        comp_pin = {'ref': comp_resolved.ref, 'digest': comp_resolved.digest}
        proj_resolved = authority.resolve_profile(profile_ref)
        classes = list(proj_resolved.record['sources'])
        refs_to_class = {authority.resolve_source(proj_resolved.catalog, cls).ref: cls for cls in classes}
        assert len(coordinates['sources']) >= 2, 'need >=2 sources to test real compose source coverage'
        assert len(refs_to_class) == len(classes) == len(coordinates['sources'])
        result['setup'].update(coordinates=coordinates, composition_profile=comp_pin,
                               source_class_by_ref=refs_to_class, merge_strategy=comp_resolved.record['merge_strategy'])
        dump(base / 'coordinates.json', result['setup'])
    except Exception as e:
        result['setup']['coordinate_error'] = error_repr(e)
        for case in CASES:
            record_unrun(case, 'Could not resolve exact candidate coordinates: ' + repr(e))
        dump(base / 'summary.json', result)
        return result

    sources = coordinates['sources']
    proj_pin = coordinates['projection_profile']
    bad_source = wrong(sources[0]['digest'])
    bad_profile = wrong(proj_pin['digest'])
    bad_comp = wrong(comp_pin['digest'])
    original_request = {'schema': 'l9.semantic-projection-request/v1', 'authority': auth_spec,
                        'projection_profile': copy.deepcopy(proj_pin), 'sources': copy.deepcopy(sources),
                        'output_root': str(base / 'unexpected-output')}

    def project_request(doc):
        return SemanticCompiler().project(ProjectionRequest.from_dict(doc))

    missing_request = copy.deepcopy(original_request)
    missing_request['sources'] = missing_request['sources'][1:]
    missing_source_ref = sources[0]['ref']
    test('01_missing_source_pin', lambda: project_request(missing_request),
         lambda e: assertion_map(source_was_declared=missing_source_ref in e.diagnostics.get('declared', []),
                                 source_pin_absent=missing_source_ref not in e.diagnostics.get('pinned', []),
                                 only_requested_pin_missing=set(e.diagnostics.get('declared', []))-set(e.diagnostics.get('pinned', [])) == {missing_source_ref},
                                 not_a_missing_source_file='declared' in e.diagnostics and 'pinned' in e.diagnostics),
         {'removed_source_pin': sources[0], 'canonical_source_class': refs_to_class[missing_source_ref],
          'method': 'SemanticCompiler.project(ProjectionRequest.from_dict(...))'})

    wrong_source_request = copy.deepcopy(original_request)
    wrong_source_request['sources'][0]['digest'] = bad_source
    test('02_wrong_source_pin', lambda: project_request(wrong_source_request),
         lambda e: assertion_map(ref=e.diagnostics.get('ref') == missing_source_ref,
                                 expected_digest_is_supplied_bad_pin=e.diagnostics.get('expected_digest') == bad_source,
                                 observed_digest_is_exact_source_pin=e.diagnostics.get('observed_digest') == sources[0]['digest']),
         {'source_ref': missing_source_ref, 'exact_pin': sources[0]['digest'], 'supplied_pin': bad_source})

    wrong_profile_request = copy.deepcopy(original_request)
    wrong_profile_request['projection_profile']['digest'] = bad_profile
    test('03_wrong_profile_pin', lambda: project_request(wrong_profile_request),
         lambda e: assertion_map(ref=e.diagnostics.get('ref') == profile_ref,
                                 expected_digest_is_supplied_bad_pin=e.diagnostics.get('expected_digest') == bad_profile,
                                 observed_digest_is_exact_profile_pin=e.diagnostics.get('observed_digest') == proj_pin['digest']),
         {'exact_pin': proj_pin['digest'], 'supplied_pin': bad_profile})

    # Independently generate genuine producer artifacts/receipts within this profile's fresh root.
    try:
        valid_request = copy.deepcopy(original_request)
        valid_request['output_root'] = str(base / 'producer-emissions')
        projected = project_request(valid_request)
        assert projected.status == 'succeeded', projected.status
        paths = [Path(a.path) for a in projected.artifacts]
        assert len(paths) == len(sources)
        emitted = []
        for art in projected.artifacts:
            document = load_artifact_file(art.path)
            receipt = load_artifact_file(art.receipt_path)
            assert document['source_ref'] in refs_to_class
            assert art.result == receipt['result'] == 'unknown', (art.result, receipt['result'])
            assert receipt['inputs'][0]['revision'] == REVISION
            emitted.append({'path': str(art.path), 'file_sha256': sha(art.path), 'ref': art.ref,
                            'source_ref': document['source_ref'], 'source_class': refs_to_class[document['source_ref']],
                            'projection_digest': art.digest, 'result': art.result,
                            'receipt_path': str(art.receipt_path), 'receipt_sha256': sha(art.receipt_path),
                            'receipt_result': receipt['result'], 'receipt_digest': receipt['receipt_digest']})
        assert projected.result == 'unknown', projected.result
        assert {x['source_ref'] for x in emitted} == {x['ref'] for x in sources}
        result['setup']['emission'] = {'status': projected.status, 'result': projected.result, 'artifacts': emitted}
        dump(base / 'emission-index.json', result['setup']['emission'])
    except Exception as e:
        result['setup']['emission_error'] = error_repr(e)
        for case in list(CASES)[3:]:
            record_unrun(case, 'Genuine candidate producer artifacts/unknown receipts unavailable: ' + repr(e))
        dump(base / 'summary.json', result)
        return result

    # Each modification is confined to a distinct test copy, never producer-emitted bytes.
    original_path = paths[0]
    original = load_artifact_file(original_path)
    receipt_path = Path(projected.artifacts[0].receipt_path)
    orig_receipt = load_artifact_file(receipt_path)
    replaced_paths = [str(p) for p in paths]

    def compose(component_paths, pin=comp_pin):
        req = {'schema': 'l9.semantic-composition-request/v1', 'authority': auth_spec,
               'composition_profile': pin, 'components': list(component_paths),
               'output_root': str(base / 'unexpected-output')}
        return SemanticCompiler().compose(CompositionRequest.from_dict(req))

    def write_copy(case, document):
        path = base / 'tampered-copies' / (case + '.json')
        dump(path, document)
        return path

    try:
        no_digest = copy.deepcopy(original)
        assert isinstance(no_digest['payload'], dict)
        assert '__negative_control__' not in no_digest['payload']
        no_digest['payload']['__negative_control__'] = 'tampered-copy-only'
        no_digest_path = write_copy('04_payload_tamper_no_redigest', no_digest)
        altered_paths = [str(no_digest_path), *replaced_paths[1:]]
        computed_digest = envelope_digest(no_digest, 'projection_digest')
        test('04_payload_tamper_no_redigest', lambda: compose(altered_paths),
             lambda e: assertion_map(retained_original_digest=no_digest['projection_digest'] == original['projection_digest'],
                                     original_and_tampered_payload_differ=original['payload'] != no_digest['payload'],
                                     recomputed_digest_differs=computed_digest != no_digest['projection_digest'],
                                     observed_is_retained=e.diagnostics.get('observed_digest') == original['projection_digest'],
                                     expected_is_real_recomputed=e.diagnostics.get('expected_digest') == computed_digest),
             {'copy': str(no_digest_path), 'original': str(original_path), 'computed_but_not_written_digest': computed_digest,
              'method': 'SemanticCompiler.compose with tampered component first'})
    except Exception as e:
        record_unrun('04_payload_tamper_no_redigest', 'Could not prepare copied input: ' + repr(e))

    try:
        redigested = copy.deepcopy(original)
        redigested['payload']['__negative_control__'] = 'tampered-copy-only'
        redigested['projection_digest'] = envelope_digest(redigested, 'projection_digest')
        redigested_path = write_copy('05_payload_tamper_redigested', redigested)
        altered_paths = [str(redigested_path), *replaced_paths[1:]]
        test('05_payload_tamper_redigested', lambda: compose(altered_paths),
             lambda e: assertion_map(payload_changed=original['payload'] != redigested['payload'],
                                     digest_is_engine_recomputed=redigested['projection_digest'] == envelope_digest(redigested, 'projection_digest'),
                                     digest_changed=redigested['projection_digest'] != original['projection_digest'],
                                     source_ref=e.diagnostics.get('source_ref') == original['source_ref'],
                                     divergence_reported=e.first_divergence is not None),
             {'copy': str(redigested_path), 'method': 'SemanticCompiler.compose; real producer envelope_digest'})
    except Exception as e:
        record_unrun('05_payload_tamper_redigested', 'Could not prepare copied input: ' + repr(e))

    try:
        stale = copy.deepcopy(original)
        stale['source_digest'] = wrong(original['source_digest'])
        stale['projection_digest'] = envelope_digest(stale, 'projection_digest')
        stale_path = write_copy('06_forged_stale_source_digest', stale)
        altered_paths = [str(stale_path), *replaced_paths[1:]]
        test('06_forged_stale_source_digest', lambda: compose(altered_paths),
             lambda e: assertion_map(forged_digest_differs=stale['source_digest'] != original['source_digest'],
                                     envelope_digest_is_engine_recomputed=stale['projection_digest'] == envelope_digest(stale, 'projection_digest'),
                                     source_ref=e.diagnostics.get('source_ref') == original['source_ref'],
                                     observed_forged_digest=e.diagnostics.get('artifact_digest') == stale['source_digest'],
                                     observed_current_digest=e.diagnostics.get('current_digest') == original['source_digest']),
             {'copy': str(stale_path), 'simulation': 'Forged source digest on copy; no actual intervening revision',
              'method': 'SemanticCompiler.compose; real producer envelope_digest'})
    except Exception as e:
        record_unrun('06_forged_stale_source_digest', 'Could not prepare copied input: ' + repr(e))

    try:
        missing_class = refs_to_class[original['source_ref']]
        test('07_missing_component', lambda: compose(replaced_paths[1:]),
             lambda e: assertion_map(exactly_missing_class=e.diagnostics.get('missing_source_classes') == [missing_class]),
             {'omitted_real_component': str(original_path), 'omitted_source_ref': original['source_ref'],
              'omitted_source_class': missing_class, 'method': 'SemanticCompiler.compose'})
    except Exception as e:
        record_unrun('07_missing_component', 'Could not prepare compose call: ' + repr(e))

    try:
        expected_ref = projected.artifacts[0].ref
        test('08_duplicate_component', lambda: compose([*replaced_paths, replaced_paths[0]]),
             lambda e: assertion_map(exact_duplicate_ref=e.diagnostics.get('projection_refs') == [expected_ref]),
             {'duplicated_real_component': str(original_path), 'projection_ref': expected_ref,
              'method': 'SemanticCompiler.compose'})
    except Exception as e:
        record_unrun('08_duplicate_component', 'Could not prepare compose call: ' + repr(e))

    try:
        test('09_wrong_composition_profile_pin', lambda: compose(replaced_paths, {'ref': composition_ref, 'digest': bad_comp}),
             lambda e: assertion_map(ref=e.diagnostics.get('ref') == composition_ref,
                                     expected_digest_is_supplied_bad_pin=e.diagnostics.get('expected_digest') == bad_comp,
                                     observed_digest_is_exact_composition_pin=e.diagnostics.get('observed_digest') == comp_pin['digest']),
             {'exact_pin': comp_pin['digest'], 'supplied_pin': bad_comp, 'method': 'SemanticCompiler.compose'})
    except Exception as e:
        record_unrun('09_wrong_composition_profile_pin', 'Could not prepare compose call: ' + repr(e))

    try:
        changed = copy.deepcopy(orig_receipt)
        changed['claim'] += ' [tampered copy]'
        changed_path = write_copy('10_changed_receipt_no_redigest', changed)
        test('10_changed_receipt_no_redigest',
             lambda: validate_receipt_document(load_artifact_file(changed_path), expected_subject_ref=projected.artifacts[0].ref),
             lambda e: assertion_map(digest_mismatch_message=str(e) == 'prior compilation receipt digest mismatch',
                                     retained_original_digest=changed['receipt_digest'] == orig_receipt['receipt_digest'],
                                     retained_unknown_result=changed['result'] == orig_receipt['result'] == 'unknown',
                                     changed_claim=changed['claim'] != orig_receipt['claim'],
                                     reported_digest_is_original=e.diagnostics.get('observed_digest') == orig_receipt['receipt_digest'],
                                     expected_computed_digest_differs=e.diagnostics.get('expected_digest') != orig_receipt['receipt_digest']),
             {'original_receipt': str(receipt_path), 'changed_copy': str(changed_path),
              'method': 'engine.receipts.validate_receipt_document (producer helper, not independent consumer)'})
    except Exception as e:
        record_unrun('10_changed_receipt_no_redigest', 'Could not prepare copied receipt: ' + repr(e))

    # Verify emitted originals were not touched by any of the tests.
    original_integrity = []
    for e in emitted:
        original_integrity.append({'path': e['path'], 'same': sha(e['path']) == e['file_sha256'],
                                   'receipt_path': e['receipt_path'], 'receipt_same': sha(e['receipt_path']) == e['receipt_sha256']})
    result['setup']['original_emissions_integrity'] = original_integrity
    if not all(e['same'] and e['receipt_same'] for e in original_integrity):
        result['warnings'].append('Original emitted artifact or receipt changed unexpectedly')
    dump(base / 'summary.json', result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profiles', nargs='+', choices=NAMES, default=NAMES)
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()
    if len(set(args.profiles)) != len(args.profiles) or args.workers < 1:
        parser.error('profiles must be distinct and workers must be positive')
    assert Path(sys.executable).resolve() == (QA / 'venv/bin/python').resolve(), 'use the pinned QA venv python'
    assert Path(l9_semantic_compiler.__file__).resolve().is_relative_to((QA / 'venv').resolve())
    before = {'candidate_head': git(QA / 'candidate', 'rev-parse', 'HEAD'),
              'candidate_status': git(QA / 'candidate', 'status', '--porcelain=v1', '--untracked-files=all'),
              'compiler_head': git(QA / 'compiler', 'rev-parse', 'HEAD')}
    assert before['candidate_head'] == REVISION, before
    assert before['compiler_head'] == COMPILER_REVISION, before
    run = Path(tempfile.mkdtemp(prefix='run-', dir=OUTPUT))
    metadata = {'started_utc': utc(), 'qa': str(QA), 'candidate_revision': REVISION,
                'producer_checkout_revision': COMPILER_REVISION, 'python': sys.executable,
                'producer_module': l9_semantic_compiler.__file__, 'producer_version': SemanticCompiler.version,
                'envelope_digest_function': f'{envelope_digest.__module__}.{envelope_digest.__name__}',
                'candidate_before': before, 'profiles': args.profiles, 'workers': args.workers,
                'scope': 'producer negative diagnostics only; no candidate qualification or independent replay',
                'limitations': ['All artifacts and receipts emitted by SemanticCompiler.project are result=unknown; no passing bundle is claimed.',
                                'Stale source is a simulated mismatch in a copied envelope, not an intervening revision.',
                                'Receipt validation uses the producer helper, not an independent consumer.',
                                'One emitted component and one receipt per profile are targeted; no exhaustive tamper search.']}
    dump(run / 'metadata.json', metadata)
    print(f'RUN {run} revision={REVISION} producer={COMPILER_REVISION} profiles={len(args.profiles)}', flush=True)
    results = {}
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(run_profile, name, str(run)): name for name in args.profiles}
        for future in as_completed(futures):
            name = futures[future]
            try:
                r = future.result()
            except Exception as exc:
                # A process-level failure is recorded per case, rather than aborting remaining profiles.
                r = {'name': name, 'setup': {'worker_error': error_repr(exc)}, 'cases': {}, 'warnings': ['worker failed']}
                for case, (code, criterion, requirement) in CASES.items():
                    item = {'case': case, 'status': 'unrun', 'reason': 'Worker failure: ' + repr(exc),
                            'expected': {'code': code, 'criterion': criterion, 'requirement': requirement}, 'observed': None}
                    r['cases'][case] = item
                    dump(run / 'profiles' / name / 'cases' / f'{case}.json', item)
                dump(run / 'profiles' / name / 'summary.json', r)
            results[name] = r
            counts = {s: sum(c['status'] == s for c in r['cases'].values()) for s in ('passed', 'failed', 'unrun')}
            print(f"PROFILE {name} passed={counts['passed']} failed={counts['failed']} unrun={counts['unrun']}", flush=True)
            for case, item in r['cases'].items():
                ob = item.get('observed') or {}
                print(f"  {item['status'].upper()} {case} expected={item['expected']['code']}/{item['expected']['criterion']} observed={ob.get('code')}/{ob.get('criterion')}", flush=True)
    after = {'candidate_head': git(QA / 'candidate', 'rev-parse', 'HEAD'),
             'candidate_status': git(QA / 'candidate', 'status', '--porcelain=v1', '--untracked-files=all'),
             'compiler_head': git(QA / 'compiler', 'rev-parse', 'HEAD')}
    totals = {s: sum(c['status'] == s for r in results.values() for c in r['cases'].values()) for s in ('passed', 'failed', 'unrun')}
    overview = {'completed_utc': utc(), 'profiles': {n: {s: sum(c['status'] == s for c in results[n]['cases'].values()) for s in ('passed', 'failed', 'unrun')} for n in args.profiles},
                'totals': totals, 'candidate_before': before, 'candidate_after': after,
                'checkout_unchanged_by_status': before == after,
                'emitted_originals_unchanged': all(not r.get('warnings') for r in results.values()),
                'scope': metadata['scope'], 'limitations': metadata['limitations']}
    dump(run / 'summary.json', overview)
    print(f"TOTAL passed={totals['passed']} failed={totals['failed']} unrun={totals['unrun']}", flush=True)
    print(f"CHECK candidate_checkout_status_unchanged={before == after} original_emissions_unchanged={overview['emitted_originals_unchanged']}", flush=True)
    print(f'SUMMARY {run / "summary.json"}', flush=True)
    return int(totals['failed'] > 0 or totals['unrun'] > 0 or before != after or not overview['emitted_originals_unchanged'])


if __name__ == '__main__':
    sys.exit(main())
