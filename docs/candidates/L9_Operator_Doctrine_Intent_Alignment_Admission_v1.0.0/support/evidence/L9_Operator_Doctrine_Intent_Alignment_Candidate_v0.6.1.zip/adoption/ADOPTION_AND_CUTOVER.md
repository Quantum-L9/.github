# Operator Doctrine and Strategic Intent adoption | Proposed

**All exact text remains CANDIDATE; no repository publication or authority admission is claimed.** The operator explicitly approved the two-file architecture and Compounding Leverage meaning. The five extra Core Values remain proposals.

## Candidate files and precedence

1. `strategy/OPERATOR_DOCTRINE.yaml`: operator-owned foundational ideology and approved-in-principle Compounding Leverage; candidate peer values are marked proposed.
2. `strategy/operator_strategic_intent.candidate.yaml`: L9-specific enduring intent pinned to `qap/operator-doctrine@0.1.0`.
3. Strategic Plan: its separately owned, in-flight graph references the *admitted* Intent revision via existing `strategic_intent_refs`. No alteration to Plan is part of this pack.

Neither operator record changes global `.github/semantics` nor creates new global primitives. An ordinary Git commit does not establish strategic authority by itself.

## Adoption sequence

1. Review and explicitly approve exact Doctrine content, resolving proposed values (adopt/reject/defer); record authority, scope, exact digest and revision.
2. Review and approve the Intent against that exact Doctrine revision; do not silently elevate candidate values.
3. Publish approved instances under the private `.github/strategy/` namespace only through authorized process and verified single-writer controls. Consider enforced access boundaries if repository-wide read access would expose strategic detail to coding agents.
4. Bind authorized strategic-role projections and separately authorize the Plan Keeper to reference exact Intent revision. Coding agents receive bounded task contracts, not direct plan/ideology authority.
5. On future Doctrine change, assess affected Intent obligations and then affected Plan closure; no automatic revision.

## One-writer future Memory cutover

A future Memory transition must prove fidelity of both independent records, authority metadata, exact revision references, access limits, restart readback, and denial of dual-writer overlap. Switch Git to a historical read-only export when Memory becomes active, never dual-edit or auto-reconcile divergent sources.

## Evidence and limitations

- `.github` checked against frozen main `dd780b957b301acf5443013708105b7a76e3aa7b`, but no producer-validated AuthorityResolution/semantic admission is claimed.
- Original v0.4.0 Dropbox harvest evidence is preserved without being reclassified as operator approval.
- `capture.yaml` covers six visible, relevant operator user turn excerpts and cites no inaccessible chat content. It cannot certify whole-chat completeness or independent review.
- Structural validators check file and reference mechanics. Proposed agent behavior scenarios remain unexecuted.

## v0.6.0 role-view successor (candidate)

The operator accepted the one-profile/four-privileged-role design and explicitly added a fifth **Coding Agent** view. This accepts the architecture direction, not exact wording, role permissions, profile admission or implementation. The candidate bindings and denied-access conditions are detailed in `alignment/ALIGNMENT_INTEGRATION.md`. The earlier two-record sources retain their existing exact revisions and byte content.

Do not activate any binding until the exact Doctrine and Intent are operator-authorized and the downstream source, compiler/adapter, global profiles, host identities, and per-role source read permissions pass the appropriate independent proofs. Only an authorized upstream agent may read protected strategy and derive bounded task obligations for coding agents.

## v0.6.1 alignment audit addition

The new source-leaf mapping/quotation/hashing checks and restricted Coding Agent preview are local candidate hardening. They are not host-level permission enforcement or operator approval of the six paraphrased Coding Agent obligations. The independent origin donor and end-to-end alignment runtime remain unverified. Inspect `validation/RECURSIVE_ALIGNMENT_AUDIT.yaml` before any admission or consumer activation.
