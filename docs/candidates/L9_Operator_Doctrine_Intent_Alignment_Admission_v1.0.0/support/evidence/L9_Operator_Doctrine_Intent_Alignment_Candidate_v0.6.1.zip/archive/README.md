The archived capture.yaml is an unmodified v0.1.0 predecessor receipt. It does not validate v0.3.0 changes. New donor dispositions and source observations are in harvest/ and provenance/.
