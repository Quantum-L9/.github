# Operator-alignment integration contract | v0.6.1 candidate

**Decision:** One operator-owned Doctrine and one Intent, one scoped alignment-selection profile, five audience-specific derived role views, and consumer-owned bindings. The fifth role is **Coding Agent**, with a task-only view. This is an accepted **design direction**, not exact artifact admission or runtime completion.

## Ownership and information flow

1. Operator-owned editable sources: `strategy/OPERATOR_DOCTRINE.yaml` and `strategy/operator_strategic_intent.candidate.yaml` (both currently candidates). Intent references the exact Doctrine revision. There is no second editable ideology or charter.
2. Global `.github/semantics` owns global law, its existing closed eight-domain projection collection, projection and composition contracts, and the current domain consumer bindings. Those canonical profiles are NOT modified or duplicated here.
3. The *operator-scoped* selection profile `alignment/operator_alignment.profile.candidate.yaml` describes how an authorized owner-scoped view producer would select Doctrine and Intent content. Its local preview renderer is NOT the semantic compiler. No `l9.projection-artifact/v1`, PASS receipt, or new global domain is fabricated.
4. Role-specific views are specified in `alignment/agent_views.candidate.yaml`. For Planner, Meta Planner, CTO, Architect, they select bounded original operator values and purpose. Their live context additionally requires genuinely authorized and independently verified Plan, global, and task evidence.
5. Coding Agent receives only a trusted upstream **delegated task-obligation view**, carrying task-specific requirements, guardrails, and acceptance obligations. No raw Doctrine, Intent, or Strategic Plan, and no attempt to infer upstream purpose from restricted sources. The source-code owner still owns local software contracts.
6. `alignment/consumer_bindings.candidate.yaml` links each view to a known existing entrypoint or explicitly unresolved consumer. No binding activation or host permission changes are asserted.

## Privileged versus Coding Agent view

Coding Agent is not merely a privileged view with its fields visually hidden. It is a different downstream product of a trusted scope-restricted transformation from the authorized task contract. The privileged input is processed **upstream** of the coding worker; the worker cannot request the underlying fields. This requires actual source/credential isolation at the execution host, especially because private GitHub repositories do not offer per-file secrecy to readers.

Never attach the complete candidate ZIP, a combined all-roles preview, privileged preview files, or protected Plan source to a Coding Agent. The `alignment/previews/coding_agent.preview.json` file is a local **example** only, not access-control proof or an active execution contract.

## Proposed activation and proof sequence

1. Obtain exact operator approval and admission coordinates for the Doctrine and Intent; resolve owner actor/rights and the authoritative private source. Until then all five views remain NONACTIVE candidate previews.
2. Independently bind current `.github` canonical global law and producer contract; confirm the currently registered global-only source limitation. Keep global projection bundles and trusted-replay verification unchanged.
3. Resolve a bounded source-owned alignment-view generator and output verification contract. Prefer existing supported machinery where proven. Any extension for operator sources belongs to its legitimate owner and needs independent admission; do not force operator YAML into `semantics/canonical_sources.yaml`.
4. Wire CTO and Architect through the existing opt-in `/lcto` and `/architect` mode entrypoints. Planner `/planner` and Meta Planner entrypoint are unresolved until implemented by their consumer owner. Existing role projections do not switch implicitly.
5. Build a trusted upstream Coding Agent delegation renderer whose task output contains selected bounded obligations but never raw Doctrine, Intent or protected Plan. Enforce actual credentials/ACLs at the host; independently test denial of direct private-file reads and prohibited scope expansion.
6. At runtime, verify exact source and profile digests, authorized consumer/actor identity, selected-source closure, negative tests, and whether any required global producer receipt fails. Compose only in the consumer context under existing provenance and conflict rules. Revisions invalidate affected views and trigger review, not automatic strategy mutation.
7. Run `tests/alignment_acceptance_scenarios.yaml` through real host integrations and observe both positive and adversarial behavior. Local previews prove only deterministic selection and redaction at this candidate pack boundary.

## Scope and deliberate omissions

No new canonical `OperatorAlignment` global source class, authority class, worldwide doctrine, ninth global projection domain, extra graph writer, synchronization database, generic alignment score or automatic governance override is proposed. No runtime command, CI invocation, compiler extension or repository mutation is authorized by this pack.

The operator approved this **architecture** and addition of the Coding Agent view. Exact YAML content, operator rights, admission status, compatibility with a live operator-source producer, and host access controls remain separately unproven.

## v0.6.1 bounded alignment controls

- The operator-scoped selection profile alone defines a privileged selector allowlist; all four privileged view definitions consume subsets. The renderer independently rejects broad `/core_values` and any proposed `/additional_core_value_candidates` paths.
- Coding Agent obligation review lives **upstream** in `alignment/agent_views.candidate.yaml` and has exact source leaf pointer, source quote and leaf hash. The summary remains an unadmitted candidate interpretation. The worker preview transports only its obligation ID and summary, never upstream coordinates, raw source text, per-source digests, or protected Plan state.
- A preview has `can_activate=false` and a null runtime receipt. The Coding Agent preview explicitly says there is no task contract attached. Neither a preview nor a local negative test can prove source confidentiality or authorization.
- Verification now compares generated outputs without modifying the evidence under inspection. Revision drift or an unapproved selector fails locally.
- Preserved global domain projection boundaries remain controlling. No new registered global domain, pseudo-compiler receipt, or independent alignment authority has been added.
