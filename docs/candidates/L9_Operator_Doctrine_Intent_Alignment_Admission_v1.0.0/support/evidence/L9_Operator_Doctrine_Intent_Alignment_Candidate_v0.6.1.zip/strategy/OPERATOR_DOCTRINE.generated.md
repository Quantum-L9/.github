# Operator Doctrine v0.1.0 | CANDIDATE

> Read-only generated view. Edit only `strategy/OPERATOR_DOCTRINE.yaml`.

## Foundational ideology
- **Status:** operator_endorsed_in_principle_exact_wording_candidate
- **Central Thesis:** Durable progress compounds: meaningful achievement should increase the capacity to achieve comparable future outcomes instead of producing isolated bursts of activity.
- **Progress Test:** On a defensible comparable baseline, subsequent outcomes should be demonstrably easier, cheaper, faster, more reliable, or more autonomous, without sacrificing necessary quality, integrity or control.
- **Flywheel:** Verified outcomes and admitted learning strengthen reusable capability; stronger capability reduces repeated effort and opens further authorized opportunities; improvements must be observed, not declared.

## Operator-endorsed-in-principle core value
### Compounding Leverage
- **Status:** operator_endorsed_in_principle_exact_wording_candidate
- **Statement:** Prefer choices that increase future authorized capacity through reusable capability, validated learning, reduced recurring friction and retained optionality.
- **Guardrail:** Necessary one-off work, contractual obligations and safety or legal repairs remain valid even without compounding returns. Leverage never overrides governing obligations.

## Other core values (proposed, NOT adopted)
- **Truth And Evidence:** Distinguish observed fact, inference, forecast and aspiration; do not upgrade unsupported claims to truth. [PROPOSED]
- **Autonomy And Accountability:** Increase independent competence without transferring strategic, legal or financial authority by implication. [PROPOSED]
- **Simplicity And Irreducibility:** New complexity should satisfy a current obligation or produce justified compounding benefit. [PROPOSED]
- **Sovereignty And Independence:** Protect legitimate ownership, portable capabilities and freedom of strategic action. [PROPOSED]
- **Durable Value Creation:** Prefer independently verifiable long-term economic and operating benefit to apparent activity or prestige. [PROPOSED]

## First Principles
- **Status:** derived_candidates_from_endorsed_ideology_not_independently_adopted
- **Comparability:** Assess compounding against a relevant baseline and comparable outcomes rather than arbitrary activity volume.
- **Bounded Leverage:** Compounding is a portfolio/system-level directional preference, not a universal requirement that every task yield a reusable artifact.
- **No False Optimization:** Any faster or cheaper alternative that violates applicable law, authority, privacy, safety or required quality is inadmissible.
- **Learning Is Not Authority:** Evidence may challenge application of principles but does not authorize an agent to revise the operator Doctrine or a Strategic Intent.

## Convictions
- **Status:** candidate_normative_philosophy_not_empirical_fact
- **Statement:** Capability should accumulate through evidence-governed reuse, and the operator should increasingly direct outcomes rather than repeat routine execution.
- **Boundary:** Causal product forecasts, market claims, algorithms and estimated financial returns remain testable hypotheses in the Plan or their source-owning domains.

## Boundaries
- **Higher Order Law:** Applicable law and admitted global governance obligations govern every application of this Doctrine.
- **No Personal Semantics Globalization:** Core values remain operator scoped and never become new universal L9 invariants by file placement, repetition or model preference.
- **Single Authoritative Writer:** At most one active, operator-authorized editing surface per adopted Doctrine revision. The temporary proposed home is private Git; a future Memory cutover must be explicit and single writer.
- **No Automatic Downstream Revisions:** Revising Doctrine triggers an impact review for bound Strategic Intent and Plans; it does not automatically amend them.
- **Availability Not Authority:** An agent reading a doctrine, charter or private repository gains no extra permission, legal role or Strategic Authority.

## Intent Relationship
- **Dependent Ref:** qap/l9-operator-strategic-intent
- **Dependent Candidate Revision:** 0.5.0
- **Role:** Doctrine supplies foundational meaning and constraints; Intent supplies the chosen L9-specific enduring purpose. Intent and Plan must use exact applicable revisions without copying Doctrine values into separate editable sources.

## Storage Proposal
- **Current Candidate Home:** Quantum-L9/.github/strategy/OPERATOR_DOCTRINE.yaml (not yet committed)
- **Future Home:** Only after explicitly approved and verified single-writer Memory cutover; no dual editing or automatic synchronization.
