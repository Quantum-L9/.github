#!/usr/bin/env python3
"""Read-only, local candidate structure and evidence checks. No live assurance claims."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import yaml

ROOT = Path(__file__).resolve().parents[1]
issues = []


def raw(path):
    return (ROOT / path).read_bytes()


def digest(path):
    return hashlib.sha256(raw(path)).hexdigest()


def read_yaml(path):
    return yaml.safe_load(raw(path))


def check(condition, error):
    if not condition:
        issues.append(error)


D = read_yaml('strategy/OPERATOR_DOCTRINE.yaml')
I = read_yaml('strategy/operator_strategic_intent.candidate.yaml')
P = read_yaml('alignment/operator_alignment.profile.candidate.yaml')
V = read_yaml('alignment/agent_views.candidate.yaml')
B = read_yaml('alignment/consumer_bindings.candidate.yaml')
C = read_yaml('capture.yaml')
M = json.loads(raw('manifest.json'))
old = read_yaml('tests/acceptance_scenarios.yaml')['cases']
new = read_yaml('tests/alignment_acceptance_scenarios.yaml')['cases']

check(D['revision'] == '0.1.0' and I['revision'] == '0.5.0', 'unauthorized operator source content revision')
check(D['authority_class'] == 'candidate_not_admitted' and I['authority_class'] == 'candidate_not_admitted', 'authority overclaim')
check(I['doctrine_binding']['doctrine_ref'] == D['doctrine_ref'] and I['doctrine_binding']['doctrine_revision'] == D['revision'], 'invalid Doctrine-Intent binding')
check(all(x['status'] == 'proposed_not_operator_adopted' for x in D['additional_core_value_candidates'].values()), 'proposed values falsely admitted')
check(len(old) == 37 and len(new) == 18, 'acceptance-scenario count changed unexpectedly')
ids = [s['id'] for s in old + new]
check(len(ids) == len(set(ids)), 'duplicate scenario ID')
check(P['pack_revision'] == '0.6.1', 'candidate pack revision mismatch')
check(P['decision_status'] == 'operator_approved_structure_exact_text_and_runtime_not_admitted', 'candidate status overclaim')
check(V['version'] == '0.1.1', 'role view specification revision mismatch')
for name, spec in P['source_instances'].items():
    check(digest(spec['path']) == spec['sha256'], 'source integrity mismatch ' + name)
    check(read_yaml(spec['path'])['revision'] == spec['revision'], 'source revision mismatch ' + name)
check(P['source_instances']['intent']['must_reference_doctrine_revision'] == D['revision'], 'Intent/Doctrine revision closure mismatch')
check(set(V['views']) == {'planner', 'meta_planner', 'cto', 'architect', 'coding_agent'}, 'expected five role views')
check(set(B['bindings']) == set(V['views']), 'consumer/view inventory mismatch')
allowed = P['selection_policy']['privileged_selector_allowlist']
for role, view in V['views'].items():
    check(B['bindings'][role]['view_ref'] == view['view_ref'], 'view/binding mismatch ' + role)
    check(view['privileged'] is (role != 'coding_agent'), 'privilege incorrect ' + role)
    if role != 'coding_agent':
        for source, pointer_field in (('doctrine','doctrine_paths'),('intent','intent_paths')):
            paths = view[pointer_field]
            check(set(paths).issubset(set(allowed[source])), 'privileged selector not allowed ' + role)
            check(not any(x == '/core_values' or x.startswith('/additional_core_value_candidates') for x in paths), 'unapproved source selection ' + role)
ca = V['views']['coding_agent']
check(ca['doctrine_paths'] == [] and ca['intent_paths'] == [], 'coding agent has raw operator source selections')
check('raw_operator' not in B['bindings']['coding_agent']['scope'], 'coding scope incorrect')
for o in ca['delegated_obligations']:
    ref = D if o['source'] == 'doctrine' else I
    val = ref
    try:
        for part in o['pointer'].strip('/').split('/'):
            val = val[part]
        check(isinstance(val,str), 'obligation source must be a string leaf')
        if isinstance(val,str):
            check(o['evidence_quote'] in val, 'obligation evidence quote mismatch')
            check(hashlib.sha256(val.encode('utf-8')).hexdigest() == o['source_value_sha256'], 'obligation source value digest mismatch')
    except (KeyError, TypeError):
        issues.append('missing coding source pointer ' + o['id'])
    check(o['summary_review_state'] == 'candidate_requires_operator_review_before_delegation', 'unapproved obligation silently promoted')

# Prove generated file bytes without modifying the evidence being checked.
with tempfile.TemporaryDirectory() as temp:
    sandbox = Path(temp)
    (sandbox / 'strategy').mkdir()
    (sandbox / 'tools').mkdir()
    shutil.copy(ROOT / 'tools/render_intent.py', sandbox / 'tools/render_intent.py')
    for src in ('OPERATOR_DOCTRINE.yaml','operator_strategic_intent.candidate.yaml'):
        shutil.copy(ROOT / 'strategy' / src, sandbox / 'strategy' / src)
    proc = subprocess.run([sys.executable, str(sandbox / 'tools/render_intent.py')], capture_output=True, text=True)
    if proc.returncode:
        issues.append('intent generator failed: ' + proc.stderr[-300:])
    else:
        for name in ('OPERATOR_DOCTRINE.generated.md','STRATEGIC_INTENT.generated.md'):
            check((sandbox / 'strategy' / name).read_bytes() == raw('strategy/' + name), 'intent generation mismatch ' + name)
proc = subprocess.run([sys.executable, str(ROOT / 'tools/render_alignment.py'), '--check'], capture_output=True, text=True)
if proc.returncode:
    issues.append('render alignment read-only check: ' + proc.stderr[-250:])

# Reject privileged source or pointer coordinates inside the restricted coding preview.
preview = json.loads(raw('alignment/previews/coding_agent.preview.json'))
check(preview.get('can_activate') is False and preview.get('runtime_receipt') is None, 'coding preview falsely active')
check(preview.get('example_only_no_task_contract_attached') is True, 'coding preview incorrectly task bound')
for forbidden_field in ('selected_operator_sections','source_revision_refs','source_sha256','upstream_provenance_ref','source_ref','source_pointer'):
    check(forbidden_field not in preview, 'coding preview restricted reference leak ' + forbidden_field)
check(all(set(o) == {'id','summary'} for o in preview['delegated_obligations']), 'coding preview internal provenance leak')
for v in preview['delegated_obligations']:
    check(not any(s in json.dumps(v).lower() for s in ('doctrine:', 'intent:', '/core_values/', '/content/')), 'coding preview raw source pointer leak')
for name in V['views']:
    p = json.loads(raw('alignment/previews/' + name + '.preview.json'))
    check(p.get('can_activate') is False and p.get('runtime_receipt') is None, 'preview activation overclaim ' + name)
    if name != 'coding_agent':
        check('selected_operator_sections' in p, 'privileged preview missing selected content ' + name)

# Bound, partial donor snapshot. No completeness or outside-source claims.
check(C['source']['completeness'] == 'partial', 'capture incorrectly claims complete donor')
check(digest(C['source']['path']) == C['source']['sha256'], 'capture donor snapshot mismatch')
messages = [json.loads(s) for s in raw(C['source']['path']).decode('utf-8').splitlines() if s.strip()]
by_id = {m['id']:m for m in messages}
check(len(messages) == 6 and len(by_id) == 6, 'visible donor boundary has unexpected message count')
check([m['id'] for m in messages] == [m['message_id'] for m in C['message_coverage']], 'message coverage/order mismatch')
claims = {c['id']:c for c in C['claims']}
for row in C['message_coverage']:
    check(bool(row['claim_ids']), 'material message missing claims ' + row['message_id'])
    for claim_id in row['claim_ids']:
        check(claim_id in claims, 'coverage points to missing claim ' + claim_id)
for c in C['claims']:
    for e in c['evidence']:
        check(e['message_id'] in by_id and e['quote'] in by_id[e['message_id']]['content'], 'donor quote mismatch ' + c['id'])
    for target in c.get('expression',[]):
        ptr_obj = read_yaml(target['path'])
        try:
            for part in target['pointer'].strip('/').split('/'):
                if isinstance(ptr_obj, list):
                    ptr_obj = ptr_obj[int(part)]
                elif isinstance(ptr_obj, dict):
                    ptr_obj = ptr_obj[part.replace('~1', '/').replace('~0', '~')]
                else:
                    raise TypeError('unresolvable path')
        except (KeyError, TypeError, IndexError, ValueError):
            issues.append('capture target pointer mismatch ' + c['id'])
for a in C['artifacts']:
    check(digest(a['path']) == a['sha256'], 'capture artifact digest ' + a['path'])
check('C010' in C['coverage']['material_claim_ids'], 'successor authorization missing capture inventory')

harvest = json.loads(raw('harvest/harvest.json'))
hr = json.loads(raw('harvest/harvest-receipt.json'))
check(harvest.get('status') == 'PARTIAL' and hr.get('status') == 'PARTIAL', 'historical harvest status overclaim')
report = read_yaml('validation/RECURSIVE_ALIGNMENT_AUDIT.yaml')
check(report['target_binding']['predecessor_sha256'] == M['predecessor_sha256'], 'kernel audit predecessor mismatch')
check(report['target_binding']['supplied_kernel_sha256'] == digest('sources/RECURSIVE_ALIGNMENT_KERNEL.provided.md'), 'kernel provenance digest mismatch')
check(report['audit_status'] == 'PartiallySucceeded' and report['readiness_status'] == 'Unknown', 'audit readiness overclaim')

# Own-file and generated validation state are intentionally excluded from the immutable manifest inventory.
excluded = {'manifest.json', 'validation/local_validation.json'}
actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and str(p.relative_to(ROOT)) not in excluded}
check(actual == set(M['files']), 'manifest inventory mismatch')
for path, expected in M['files'].items():
    if path in actual:
        check(digest(path) == expected, 'manifest digest mismatch ' + path)

status = 'PASS_LOCAL_STRUCTURE' if not issues else 'FAIL'
print(json.dumps({
    'status': status,
    'errors': issues,
    'role_views': len(V['views']),
    'existing_scenarios': len(old),
    'alignment_scenarios': len(new),
    'total_scenarios': len(ids),
    'operator_admission': 'NOT_RUN',
    'canonical_projection_compilation': 'NOT_RUN',
    'actual_host_permissions': 'NOT_RUN',
    'agent_behavioral_tests': 'NOT_RUN',
    'source_coverage': 'PARTIAL',
    'independent_reconstruction': 'NOT_RUN'
}, indent=2))
sys.exit(0 if not issues else 1)
