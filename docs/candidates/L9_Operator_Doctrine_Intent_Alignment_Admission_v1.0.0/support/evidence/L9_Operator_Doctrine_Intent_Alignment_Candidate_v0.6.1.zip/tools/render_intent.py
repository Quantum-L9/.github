#!/usr/bin/env python3
"""Render both candidate sources into read-only, deterministic Markdown."""
from pathlib import Path
import yaml
root=Path(__file__).resolve().parents[1]
doc=yaml.safe_load((root/'strategy/OPERATOR_DOCTRINE.yaml').read_text(encoding='utf-8'))
intent=yaml.safe_load((root/'strategy/operator_strategic_intent.candidate.yaml').read_text(encoding='utf-8'))
lines=['# Operator Doctrine v'+str(doc['revision'])+' | CANDIDATE','', '> Read-only generated view. Edit only `strategy/OPERATOR_DOCTRINE.yaml`.','', '## Foundational ideology']
for k,v in doc['foundational_ideology'].items():lines+=['- **'+k.replace('_',' ').title()+':** '+str(v)]
lines+=['','## Operator-endorsed-in-principle core value']
for k,v in doc['core_values'].items():
 lines+=['### '+k.replace('_',' ').title()]
 for f,t in v.items():lines+=['- **'+f.replace('_',' ').title()+':** '+str(t)]
lines+=['','## Other core values (proposed, NOT adopted)']
for k,v in doc['additional_core_value_candidates'].items():lines+=['- **'+k.replace('_',' ').title()+':** '+v['statement']+' [PROPOSED]']
for section in ['first_principles','convictions','boundaries','intent_relationship','storage_proposal']:
 lines+=['','## '+section.replace('_',' ').title()]
 for k,v in doc[section].items():lines+=['- **'+k.replace('_',' ').title()+':** '+str(v)]
(root/'strategy/OPERATOR_DOCTRINE.generated.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
content=intent['content']
lines=['# Operator Strategic Intent v'+str(intent['revision'])+' | CANDIDATE','', '> Read-only generated view. Edit only `strategy/operator_strategic_intent.candidate.yaml`.','', '## Exact Doctrine reference']
for k,v in intent['doctrine_binding'].items():lines+=['- **'+k.replace('_',' ').title()+':** '+str(v)]
lines+=['','## Enduring purpose',content['enduring_purpose'],'',content['enduring_product']]
for section in ['long_term_success','nonnegotiables','tradeoff_doctrine','agent_operating_philosophy','learning_and_evolution']:
 lines+=['','## '+section.replace('_',' ').title()]
 for k,v in content[section].items():lines+=['- **'+k.replace('_',' ').title()+':** '+str(v)]
for section in ['relationship_to_strategy','storage_transition']:
 lines+=['','## '+section.replace('_',' ').title()]
 for k,v in intent[section].items():lines+=['- **'+k.replace('_',' ').title()+':** '+str(v)]
lines+=['','## Deliberate exclusions',content['deliberate_exclusions']]
(root/'strategy/STRATEGIC_INTENT.generated.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
