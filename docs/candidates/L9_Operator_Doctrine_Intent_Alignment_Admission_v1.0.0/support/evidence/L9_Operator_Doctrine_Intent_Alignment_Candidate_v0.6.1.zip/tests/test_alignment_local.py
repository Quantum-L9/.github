#!/usr/bin/env python3
"""Negative local controls. Reproduce rejected candidate mutations in isolated copies."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import yaml

ROOT = Path(__file__).resolve().parents[1]
controls = []


def change_yaml(root, relative, transform):
    path = root / relative
    obj = yaml.safe_load(path.read_text(encoding='utf-8'))
    transform(obj)
    path.write_text(yaml.safe_dump(obj, sort_keys=False, allow_unicode=True), encoding='utf-8')


def reject(label, mutate, command, error, test_read_only=False):
    with tempfile.TemporaryDirectory() as temp:
        copy = Path(temp) / 'pack'
        shutil.copytree(ROOT, copy, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        mutate(copy)
        target = copy / 'alignment/previews/coding_agent.preview.json'
        before = target.read_bytes()
        proc = subprocess.run([sys.executable, str(copy / command[0]), *command[1:]], capture_output=True, text=True)
        after = target.read_bytes()
        ok = proc.returncode != 0 and error in (proc.stdout + proc.stderr)
        if test_read_only:
            ok = ok and before == after
        controls.append({'id': label, 'passed': ok, 'expected_failure': error, 'read_only': bool(test_read_only)})


def wrong_hash(root):
    change_yaml(root, 'alignment/operator_alignment.profile.candidate.yaml', lambda o: o['source_instances']['doctrine'].update(sha256='0'*64))


def raw_coding(root):
    change_yaml(root, 'alignment/agent_views.candidate.yaml', lambda o: o['views']['coding_agent'].update(doctrine_paths=['/foundational_ideology']))


def fake_authority(root):
    change_yaml(root, 'strategy/OPERATOR_DOCTRINE.yaml', lambda o: o.update(authority_class='canonical'))


def mismatch_binding(root):
    change_yaml(root, 'alignment/consumer_bindings.candidate.yaml', lambda o: o['bindings']['coding_agent'].update(view_ref='other'))


def unapproved_value(root):
    change_yaml(root, 'alignment/agent_views.candidate.yaml', lambda o: o['views']['planner']['doctrine_paths'].append('/additional_core_value_candidates'))


def fake_quote(root):
    change_yaml(root, 'alignment/agent_views.candidate.yaml', lambda o: o['views']['coding_agent']['delegated_obligations'][0].update(evidence_quote='NOT_PRESENT_IN_SOURCE'))


def fake_leaf_digest(root):
    change_yaml(root, 'alignment/agent_views.candidate.yaml', lambda o: o['views']['coding_agent']['delegated_obligations'][0].update(source_value_sha256='0'*64))


def leaked_preview(root):
    path = root / 'alignment/previews/coding_agent.preview.json'
    obj = json.loads(path.read_text())
    obj['source_revision_refs'] = {'intent': 'private_source'}
    path.write_text(json.dumps(obj, indent=2) + '\n')


def stale_preview(root):
    path = root / 'alignment/previews/coding_agent.preview.json'
    obj = json.loads(path.read_text())
    obj['delegated_obligations'][0]['summary'] = 'Altered after generation'
    path.write_text(json.dumps(obj, indent=2) + '\n')


reject('N1_SOURCE_HASH_TAMPER', wrong_hash, ['tools/render_alignment.py', '--check'], 'source integrity mismatch')
reject('N2_CODING_DIRECT_SOURCE_SELECTION', raw_coding, ['tools/render_alignment.py', '--check'], 'coding agent has raw operator source selections')
reject('N3_FALSE_SOURCE_AUTHORITY', fake_authority, ['tools/verify_pack.py'], 'authority overclaim')
reject('N4_CONSUMER_BINDING_MISMATCH', mismatch_binding, ['tools/verify_pack.py'], 'view/binding mismatch')
reject('N5_UNAPPROVED_VALUE_SELECTION', unapproved_value, ['tools/render_alignment.py', '--check'], 'privileged selector not allowed')
reject('N6_OBLIGATION_QUOTE_TAMPER', fake_quote, ['tools/render_alignment.py', '--check'], 'obligation evidence quote mismatch')
reject('N7_OBLIGATION_LEAF_DIGEST_TAMPER', fake_leaf_digest, ['tools/render_alignment.py', '--check'], 'obligation source value digest mismatch')
reject('N8_RESTRICTED_PREVIEW_REF_LEAK', leaked_preview, ['tools/verify_pack.py'], 'coding preview restricted reference leak', True)
reject('N9_PREVIEW_DRIFT_READ_ONLY', stale_preview, ['tools/render_alignment.py', '--check'], 'preview mismatch', True)

result = {
    'status': 'PASS_LOCAL_ADVERSARIAL' if all(o['passed'] for o in controls) else 'FAIL',
    'controls': controls,
    'runtime_access_proof': 'NOT_RUN',
    'production_host_verification': 'NOT_RUN',
}
print(json.dumps(result, indent=2))
sys.exit(0 if result['status'] == 'PASS_LOCAL_ADVERSARIAL' else 1)
